package net.convocatis.convocatis.receivers;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import net.convocatis.convocatis.R;
import net.convocatis.convocatis.ui.MainActivity;
import net.convocatis.convocatis.utils.Utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by reactor on 5/14/15.
 */
public class AlarmReceiver extends BroadcastReceiver {

    public static final String ALARM_ID = "ALARM_ID";
    public static final String ALARM_TITLE = "ALARM_TITLE";
    public static final String ALARM_DESCRIPTION = "ALARM_DESCRIPTION";

    @Override
    public void onReceive(Context context, Intent intent) {

        if (intent != null) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {

                int id = bundle.getInt(ALARM_ID);
                String title = bundle.getString(ALARM_TITLE);
                String description = bundle.getString(ALARM_DESCRIPTION);

                showNotification(context, id, null, title, description, true);
            }
        }
    }

    public static void showNotification(Context context, int alarmID, final String soundFileName, String title, String description, boolean text) {

        if (text) {
            alarmID *= 2;
        } else {
            alarmID *= 2;
            alarmID++;
        }

        Intent intentClick = new Intent(context, MainActivity.class);
        intentClick.putExtra(ALARM_ID, alarmID);
        PendingIntent pIntentClick = PendingIntent.getBroadcast(context, alarmID, intentClick,
                PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder n = new Notification.Builder(context)
                .setLargeIcon(BitmapFactory.decodeResource(context.getResources(), R.mipmap.ic_launcher))
                .setContentTitle(title).setContentText(description).setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pIntentClick).setAutoCancel(true).setVibrate(new long[]{0, 1000}).setPriority(Notification.PRIORITY_MAX);

        NotificationManager manager = (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);
        manager.notify(alarmID, n.build());

        MediaPlayer mMediaPlayer;
        Uri notification = null;

        if (TextUtils.isEmpty(soundFileName)) {
            notification = RingtoneManager
                    .getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        } else {
            notification = Uri.fromFile(new File(soundFileName));
        }

        mMediaPlayer = new MediaPlayer();

        try {
            mMediaPlayer.setDataSource(context, notification);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
        // mMediaPlayer = MediaPlayer.create(ctx, notification);
        final AudioManager audioManager = (AudioManager) context
                .getSystemService(Context.AUDIO_SERVICE);

        mMediaPlayer.setAudioStreamType(AudioManager.STREAM_NOTIFICATION);

        try {
            mMediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }

        mMediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            public void onPrepared(MediaPlayer arg0) {
                arg0.seekTo(0);
                arg0.start();
            }
        });
    }

    public static void cancelNotification(Context context, int alarmID) {
        NotificationManager manager = (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);
        manager.cancel(alarmID);
    }

    public static void startAlarm(Context context, long timeOffset, int alarmID, String alarmTitle, String alarmDescription) {

        Log.d("haha", "starting alarm for prayer: " + alarmDescription + " time: " + Utils.dateTimeToString(new Date(timeOffset)));

        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra(AlarmReceiver.ALARM_ID, alarmID);
        intent.putExtra(AlarmReceiver.ALARM_TITLE, alarmTitle);
        intent.putExtra(AlarmReceiver.ALARM_DESCRIPTION, alarmDescription);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context.getApplicationContext(), alarmID, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, timeOffset, pendingIntent);
    }

    public static void cancelAlarm(Context context, int alarmID) {

        Log.d("haha", "canceling alarm");

        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra(AlarmReceiver.ALARM_ID, alarmID);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context.getApplicationContext(), alarmID, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmManager.cancel(pendingIntent);
    }

}
