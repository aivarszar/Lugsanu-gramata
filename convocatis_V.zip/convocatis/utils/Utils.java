package net.convocatis.convocatis.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by reactor on 2/4/16.
 */
public class Utils {

    private final static SimpleDateFormat DB_DATE_TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private final static SimpleDateFormat DB_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    public static String dateTimeToString(Date date) {
        synchronized (DB_DATE_TIME_FORMAT) {
            return DB_DATE_TIME_FORMAT.format(date);
        }
    }

    public static String dateToString(Date date) {
        synchronized (DB_DATE_FORMAT) {
            return DB_DATE_FORMAT.format(date);
        }
    }

    public static Date dateFromString(String date) {
        synchronized (DB_DATE_FORMAT) {
            try {
                return DB_DATE_FORMAT.parse(date);
            } catch (ParseException e) {
                return null;
            }
        }
    }


    public static Date dateTimeFromString(String date) {
        synchronized (DB_DATE_TIME_FORMAT) {
            try {
                return DB_DATE_TIME_FORMAT.parse(date);
            } catch (ParseException e) {
                return null;
            }
        }
    }

}
