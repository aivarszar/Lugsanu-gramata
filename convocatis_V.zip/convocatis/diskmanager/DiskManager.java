package net.convocatis.convocatis.diskmanager;

import android.util.Log;

import net.convocatis.convocatis.MyApplication;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by reactor on 1/26/16.
 */
public class DiskManager {

    private static ExecutorService mExecutor;

    static {
        mExecutor = Executors.newFixedThreadPool(1);
    }

    public static void execute(final DiskTask diskTask) {
        mExecutor.submit(new Runnable() {
            @Override
            public void run() {

                diskTask.getData();

                MyApplication.executeOnUIThread(new Runnable() {
                    @Override
                    public void run() {
                        diskTask.privateOnDataReceived();
                    }
                });

            }
        });
    }
}
