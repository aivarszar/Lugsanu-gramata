package net.convocatis.convocatis.diskmanager;

import net.convocatis.convocatis.ui.fragments.BaseFragment;

/**
 * Created by reactor on 1/26/16.
 */
public abstract class DiskTask {

    private BaseFragment mBaseFragment;

    public abstract void getData();

    public abstract void onDataReceived();

    public void privateOnDataReceived() {
        if (mBaseFragment != null) {
            mBaseFragment.dismissProgressDialog();
        }

        onDataReceived();
    }

    public void execute(BaseFragment baseFragment) {
        mBaseFragment = baseFragment;

        if (baseFragment != null) {
            baseFragment.showProgressDialog();
        }

        DiskManager.execute(this);
    }

    public void execute() {
        execute(null);
    }
}
