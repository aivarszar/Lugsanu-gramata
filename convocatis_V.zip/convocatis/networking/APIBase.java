package net.convocatis.convocatis.networking;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

import net.convocatis.convocatis.MyApplication;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class APIBase {

    private static final byte[] SECRET_KEY_AES = new byte[]{(byte) 0x3b, (byte) 0x36, (byte) 0x3f, (byte) 0x94,
            (byte) 0xbf, (byte) 0x7c, (byte) 0xa3, (byte) 0x2e, (byte) 0xcf, (byte) 0x53, (byte) 0x04, (byte) 0x86,
            (byte) 0xe1, (byte) 0x04, (byte) 0x51, (byte) 0x67};

    private static final byte[] IV_AES = new byte[]{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00};

    private static String sUniqueID;

    public static class NullHostNameVerifier implements HostnameVerifier {

        @Override
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }

    static {
        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }

                    public void checkClientTrusted(
                            java.security.cert.X509Certificate[] certs, String authType) {
                    }

                    public void checkServerTrusted(
                            java.security.cert.X509Certificate[] certs, String authType) {
                    }
                }
        };
        // Install the all-trusting trust manager
        try {
            HttpsURLConnection.setDefaultHostnameVerifier(new NullHostNameVerifier());
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {
        }

        CookieHandler.setDefault(new CookieManager());
    }

    private static final int RESPONSE_TIMEOUT_MILLIS = 10000;


    public static class NameValue {

        String mName;
        String mValue;

        public NameValue(String name, String value) {
            mName = name;
            mValue = value;
        }

        public String getName() {
            return mName;
        }

        public String getValue() {
            return mValue;
        }
    }

    public static byte[] encryptAES(byte[] decrypted) throws Exception {
        SecretKeySpec skeySpec = new SecretKeySpec(SECRET_KEY_AES, "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec, new IvParameterSpec(IV_AES));
        return cipher.doFinal(decrypted);
    }

    private static String bytesToHex(byte[] bytes) {
        final char[] hexArray = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
        StringBuilder sb = new StringBuilder();
        int v;
        for (int j = 0; j < bytes.length; j++) {
            v = bytes[j] & 0xFF;
            sb.append(hexArray[v >>> 4]);
            sb.append(hexArray[v & 0x0F]);
        }
        return sb.toString();
    }

    private static String getIMEI(Context c) {
        TelephonyManager telephonyMgr = (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
        return telephonyMgr.getDeviceId();
    }

    private static String getWLANMAC(Context c) {
        WifiManager wifiMgr = (WifiManager) c.getSystemService(Context.WIFI_SERVICE);
        return wifiMgr.getConnectionInfo().getMacAddress();
    }

    public static String getRandomID16() {

        byte[] idBytes = new byte[16];

        Random rand = new Random();
        rand.nextBytes(idBytes);

        return bytesToHex(idBytes);
    }

    public static String getUniqueID() {

        Context c = MyApplication.get();

        if (sUniqueID != null) {
            return sUniqueID;
        }

        byte[] idBytes;

        String imei = getIMEI(c);
        String wlanmac = getWLANMAC(c);

        // generate random id if neither IMEI nor WLAN MAC is available, this
        // will only occur for devices without both WIFI hardware and 3G
        // hardware
        if (imei == null && wlanmac == null) {
            sUniqueID = getRandomID16();
            return sUniqueID;
        } else {
            String idUnencryptedString = "";

            if (imei != null) {
                idUnencryptedString += imei;
            }

            idUnencryptedString += "|";

            if (wlanmac != null) {
                idUnencryptedString += wlanmac;
            }

            try {
                idBytes = idUnencryptedString.getBytes("UTF-8");
            } catch (UnsupportedEncodingException e) {
                // This should never happen on a normal Android device but
                // return random ID just in case
                sUniqueID = getRandomID16();
                return sUniqueID;
            }

            try {
                idBytes = encryptAES(idBytes);
            } catch (Exception e) {
                // This should never happen on a normal Android device but
                // return random ID just in case
                sUniqueID = getRandomID16();
                return sUniqueID;
            }

            sUniqueID = bytesToHex(idBytes);

            return sUniqueID;
        }
    }

    private static String getQuery(List<NameValue> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;

        for (NameValue pair : params) {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(pair.getName(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(pair.getValue(), "UTF-8"));
        }

        Log.d("haha", "query: " + result);

        return result.toString();
    }


    public static synchronized String getStringFromURL(String urlString, List<NameValue> postParams) {
        InputStream is = null;
        JSONObject jObj = null;
        String out = "";

        try {
            URL url = new URL(urlString);
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();

            conn.setReadTimeout(RESPONSE_TIMEOUT_MILLIS);
            conn.setConnectTimeout(RESPONSE_TIMEOUT_MILLIS);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

            conn.setDoInput(true);
            if (postParams != null) {
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();

                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(getQuery(postParams));
                writer.flush();
                writer.close();

                os.close();
            } else {
                conn.setRequestMethod("GET");
            }

            is = conn.getInputStream();
        } catch (IOException e) {
            Log.d("haha", "problem", e);
        }

        if (is != null) {
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                is.close();
                out = sb.toString();
            } catch (Exception e) {
                Log.d("haha", "problem", e);
                return null;
            }

            Log.d("haha", "" + out);

            return out;
        } else {
            return null;
        }
    }

    public static synchronized JSONObject getJSONFromURL(String urlString, List<NameValue> postParams, boolean withRetry) {
        String json = getStringFromURL(urlString, postParams);

        boolean shouldRetry = false;

        if (withRetry) {
            if (json == null) {
                shouldRetry = true;
            } else {
                try {
                    JSONObject jo = new JSONObject(json);
                    if (jo.has("loggedin") && TextUtils.equals(jo.getString("loggedin"), "false")) {
                        shouldRetry = true;
                    }
                } catch (JSONException e) {
                    shouldRetry = true;
                }
            }
        }

        if (shouldRetry) {
            API.retryLogin();
            json = getStringFromURL(urlString, postParams);
        }

        if (json == null) {
            return null;
        }

        JSONObject jo;

        try {
            jo = new JSONObject(json);
            return jo;
        } catch (JSONException e) {
        }

        return null;
    }

    public static synchronized JSONArray getJSONArrayFromURL(String urlString, List<NameValue> postParams, boolean withRetry) {
        String json = getStringFromURL(urlString, postParams);

        boolean shouldRetry = false;

        if (withRetry) {
            if (json == null) {
                shouldRetry = true;
            } else {
                try {
                    JSONArray jo = new JSONArray(json);
                } catch (JSONException e) {
                    shouldRetry = true;
                }
            }
        }

        if (shouldRetry) {
            API.retryLogin();
            json = getStringFromURL(urlString, postParams);
        }

        if (json == null) {
            return null;
        }

        JSONArray jo;

        try {
            jo = new JSONArray(json);
            return jo;
        } catch (JSONException e) {
        }

        return null;
    }


}
