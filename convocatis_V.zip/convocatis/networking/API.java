package net.convocatis.convocatis.networking;

import android.text.TextUtils;

import com.google.android.gms.games.internal.api.NotificationsImpl;

import net.convocatis.convocatis.database.model.NotificationModel;
import net.convocatis.convocatis.database.model.ProfileModel;
import net.convocatis.convocatis.database.model.TextModel;
import net.convocatis.convocatis.database.model.TextUsageModel;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by reactor on 1/21/16.
 */
public class API extends APIBase {


//    facebook[secret_key]=ISmWUPj9b8J9ixKJaleKf1lTBEDEuN68&facebook[email]=@gmail.com&facebook[device_language]=en&facebook[location]=LV&facebook[Device_ID]=A13020SKLE9R-A13020SKLE9R&facebook[unhidden_notifications_ID][3]=3&facebook[unhidden_notifications_ID][37]=37&facebook[unhidden_notifications_ID][39]=39&facebook[unhidden_notifications_ID][66]=66

    private static final String SERVER_URL = "https://convocatis.net/api/";

    public static final String FACEBOOK_SECRET_KEY = "ISmWUPj9b8J9ixKJaleKf1lTBEDEuN68";
    public static final String GOOGLE_SECRET_KEY = "SWzutrLmuW5hvBga7JUUfVV1D9t5aL5b";
    public static final String LOGIN_SECRET_KEY = "Yudu8e9w90xdGkKSD^&*SSSLlalsajk&YU";

    public static void retryLogin() {
        String email = ProfileModel.get().email;
        String language = Locale.getDefault().getLanguage();
        String country = Locale.getDefault().getCountry();

        if (email != null) {
            facebookLogin(email, language, country);
        }
    }

    public static JSONObject facebookLogin(String email, String language, String location) {
        String uniqueID = getUniqueID();

        List<NameValue> postParams = new ArrayList<NameValue>();

        postParams.add(new NameValue("facebook[secret_key]", FACEBOOK_SECRET_KEY));
        postParams.add(new NameValue("facebook[email]", email));
        postParams.add(new NameValue("facebook[device_language]", language));
        postParams.add(new NameValue("facebook[location]", location));
        postParams.add(new NameValue("facebook[Device_ID]", uniqueID));

        return getJSONFromURL(SERVER_URL, postParams, false);
    }

    public static JSONObject googleLogin(String email, String language, String location) {
        String uniqueID = getUniqueID();

        List<NameValue> postParams = new ArrayList<NameValue>();

        postParams.add(new NameValue("google[secret_key]", GOOGLE_SECRET_KEY));
        postParams.add(new NameValue("google[email]", email));
        postParams.add(new NameValue("google[device_language]", language));
        postParams.add(new NameValue("google[location]", location));
        postParams.add(new NameValue("google[Device_ID]", uniqueID));

        return getJSONFromURL(SERVER_URL, postParams, false);
    }

    public static JSONObject emailLogin(String email, String password, String language, String location) {
        String uniqueID = getUniqueID();

        List<NameValue> postParams = new ArrayList<NameValue>();

        postParams.add(new NameValue("local[secret_key]", LOGIN_SECRET_KEY));
        postParams.add(new NameValue("local[email]", email));
        postParams.add(new NameValue("local[password]", password));
        postParams.add(new NameValue("local[device_language]", language));
        postParams.add(new NameValue("local[location]", location));
        postParams.add(new NameValue("local[Device_ID]", uniqueID));

        return getJSONFromURL(SERVER_URL, postParams, false);
    }

//    public static JSONObject logout() {
//        List<NameValue> postParams = new ArrayList<NameValue>();
//        postParams.add(new NameValue("profile[logout]", "true"));
//        return getJSONFromURL(SERVER_URL, postParams);
//    }

    public static JSONObject deleteAccount() {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("profile[delete]", "true"));
        postParams.add(new NameValue("profile[confirm]", "true"));
        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject forgotPassword(String email) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("forgot_password", "email"));
        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject changePassword(String newPassword) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("profile[password]", newPassword));
        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject updateEmailFacebook(String email) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("profile[updateEmail]", email));
        postParams.add(new NameValue("profile[key]", FACEBOOK_SECRET_KEY));

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject updateEmailGoogle(String email) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("profile[updateEmail]", email));
        postParams.add(new NameValue("profile[key]", GOOGLE_SECRET_KEY));

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject updateEmail(String email) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("profile[updateEmail]", email));
        postParams.add(new NameValue("profile[key]", LOGIN_SECRET_KEY));

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject updateName(String name, String surname, String nick) {
        List<NameValue> postParams = new ArrayList<NameValue>();

        if (name == null) {
            name = "";
        }

        if (surname == null) {
            surname = "";
        }

        if (nick == null) {
            nick = "";
        }

        postParams.add(new NameValue("profile[name]", name));
        postParams.add(new NameValue("profile[surname]", surname));
        postParams.add(new NameValue("profile[nick]", nick));

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONArray listLanguages() {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("profile[language]", "list"));
        return getJSONArrayFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject setUILanguage(long langID) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("profile[my_language]", "" + langID));
        postParams.add(new NameValue("profile[action]", "set"));

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject setTextLanguage(int langID, boolean set) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("profile[text_language]", "" + langID));

        if (set) {
            postParams.add(new NameValue("profile[action]", "set"));
        } else {
            postParams.add(new NameValue("profile[action]", "remove"));
        }

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject syncTime(long timestamp) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("sync_time", "" + timestamp));

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject seeOtherDenominations(boolean value) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("profile[denoms_other]", value ? "1" : "0"));

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONArray listDenominations() {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("denominations", "list"));

        return getJSONArrayFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject setDenomination(long denomID) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("profile[denom]", "" + denomID));

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject stopNotifications(boolean value) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("profile[notifications]", value ? "1" : "0"));

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject requestNewLanguage(String symbol, String name, String description) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("profile[add_language]", symbol));
        postParams.add(new NameValue("profile[lang_name]", name));
        postParams.add(new NameValue("profile[lang_description]", description));
        postParams.add(new NameValue("profile[action]", "set"));

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject setTheme(int themeID) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("profile[theme]", "" + themeID));
        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject makeDonation(long timestamp, float amount) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("profile[donation_amount]", "" + amount));
        postParams.add(new NameValue("profile[timestamp]", "" + timestamp));
        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject setSchedule(List<TextModel> texts) {
        List<NameValue> postParams = new ArrayList<NameValue>();

        for (int i = 0; i < texts.size(); i++) {
            TextModel textModel = texts.get(i);

            postParams.add(new NameValue("profile[schedule][ID]", "" + (i + 1)));
            postParams.add(new NameValue("profile[schedule][Text_ID]", "" + textModel.backendId));
            postParams.add(new NameValue("profile[schedule][time]", textModel.schedule));
        }

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject sendBug(String bugText, long langID) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("profile[bugtext]", "" + bugText));
        postParams.add(new NameValue("profile[Lang]", "" + langID));
        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject createGroup(long langID, String name, String description, boolean private_, boolean myDenomination) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("group[Lang]", "" + langID));
        postParams.add(new NameValue("group[new_group]", name));
        postParams.add(new NameValue("group[Description]", description));
        postParams.add(new NameValue("group[private]", private_ ? "true" : "false"));
        postParams.add(new NameValue("group[my_denomination]", myDenomination ? "true" : "false"));
        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONArray listGroups() {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("groups[list]", "all"));

        return getJSONArrayFromURL(SERVER_URL, postParams, true);
    }

    public static JSONArray listGroupMembers(long groupID) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("groups[p_group]", "" + groupID));
        postParams.add(new NameValue("groups[members]", "list"));

        return getJSONArrayFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject joinGroup(long groupID, boolean join) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("group[ID]", "" + groupID));
        postParams.add(new NameValue("group[join]", join ? "true" : "false"));

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject sendNotification(long groupID, String message) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("message[group]", "" + groupID));
        postParams.add(new NameValue("message[message]", message));

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject deleteNotifications(List<NotificationModel> ids) {
        List<NameValue> postParams = new ArrayList<NameValue>();

        for (int i = 0; i < ids.size(); i++) {
            postParams.add(new NameValue("delete_messages[ID" + i + "]", "" + ids.get(i).backendId));
        }

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject inviteToGroup(long groupID, String email, boolean admin) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("p_group[group_ID]", "" + groupID));
        postParams.add(new NameValue("p_group[invite]", email));
        postParams.add(new NameValue("p_group[admin]", admin ? "true" : "false"));

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject shareText(TextModel text) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("text[text]", text.text));
        postParams.add(new NameValue("text[lang]", "" + text.langId));
        postParams.add(new NameValue("text[original_text_Id]", "" + text.originalId));
        postParams.add(new NameValue("text[schedule]", text.schedule));
        postParams.add(new NameValue("text[text_type]", "" + text.type));
        postParams.add(new NameValue("text[code]", text.code));
        postParams.add(new NameValue("text[description]", text.title));

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject likeTexts(List<TextModel> texts) {
        List<NameValue> postParams = new ArrayList<NameValue>();

        for (int i = 0; i < texts.size(); i++) {
            if (texts.get(i).like != null) {
                postParams.add(new NameValue("texts_rating[" + texts.get(i).backendId + "]", texts.get(i).like ? "Like" : "Dislike"));
            }
        }
        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject startPrayerForNotifications(TextModel text, long start, List<NotificationModel> notifications) {
        List<NameValue> postParams = new ArrayList<NameValue>();

        postParams.add(new NameValue("texts_usage[" + text.backendId + "][start]", "" + start));

        String notificationsString = "";
        for (int i = 0; i < notifications.size(); i++) {
            notificationsString += notifications.get(i).backendId;
            if (i < notifications.size() - 1) {
                notificationsString += ",";
            }
        }

        postParams.add(new NameValue("texts_rating[notifications]", notificationsString));

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject endPrayerForNotifications(TextModel text, long end) {
        List<NameValue> postParams = new ArrayList<NameValue>();
        postParams.add(new NameValue("texts_usage[" + text.backendId + "][end]", "" + end));
        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject likeNotifications(List<NotificationModel> notifications) {
        List<NameValue> postParams = new ArrayList<NameValue>();

        for (int i = 0; i < notifications.size(); i++) {
            postParams.add(new NameValue("notif_rating[" + notifications.get(i).backendId + "]", notifications.get(i).like ? "Like" : "Dislike"));
        }
        return getJSONFromURL(SERVER_URL, postParams, true);
    }

    public static JSONObject sync(List<TextModel> textLikes, List<NotificationModel> notificationLikes, List<TextUsageModel> usage) {
        List<NameValue> postParams = new ArrayList<NameValue>();

        postParams.add(new NameValue("sync[full_sync]", "true"));

        if (textLikes != null) {
            for (TextModel text : textLikes) {
                postParams.add(new NameValue("sync[texts_rating][" + text.backendId + "]", text.like ? "Like" : "Dislike"));
            }
        }

        if (notificationLikes != null) {
            for (NotificationModel notif : notificationLikes) {
                postParams.add(new NameValue("sync[notif_rating][" + notif.backendId + "]", notif.like ? "Like" : "Dislike"));
            }
        }

        if (usage != null) {
            for (int i = 0; i < usage.size(); i++) {
                TextUsageModel us = usage.get(i);

                if (!TextUtils.isEmpty(us.notificationIds)) {
                    postParams.add(new NameValue("sync[text_usage][" + i + "][start][" + us.textId + "]", "" + us.start));
                    postParams.add(new NameValue("sync[text_usage][" + i + "][start][notifications]", "" + us.notificationIds));
                } else {
                    postParams.add(new NameValue("sync[text_usage][" + i + "][finish][" + us.textId + "]", "" + us.end));
                }
            }
        }

        return getJSONFromURL(SERVER_URL, postParams, true);
    }

}
