package net.convocatis.convocatis.networking;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.IBinder;
import android.text.TextUtils;
import android.util.Log;

import net.convocatis.convocatis.MyApplication;
import net.convocatis.convocatis.database.model.DenominationModel;
import net.convocatis.convocatis.database.model.GroupModel;
import net.convocatis.convocatis.database.model.LanguageModel;
import net.convocatis.convocatis.database.model.NotificationModel;
import net.convocatis.convocatis.database.model.ProfileModel;
import net.convocatis.convocatis.database.model.TextModel;
import net.convocatis.convocatis.database.model.TextUsageModel;
import net.convocatis.convocatis.diskmanager.DiskTask;
import net.convocatis.convocatis.receivers.AlarmReceiver;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.security.acl.Group;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class SynchronizationService extends Service {

    public interface OnSynchronizationFinishedListener {
        void onSynchronizationStarted(boolean fullSync);

        void onSynchronizationFinished(boolean fullSync, boolean success);
    }

    private static OnSynchronizationFinishedListener mOnSynchronizationFinishedListener;
    private static boolean mSynchronizationPending;
    private static boolean mShouldPerformAnotherSync;
    private static boolean mShouldPerformAnotherSyncFullSync;
    private static boolean mFullSync;

    public static void setOnSynchronizationFinishedListener(OnSynchronizationFinishedListener listener) {
        mOnSynchronizationFinishedListener = listener;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        Log.d("haha", "service is starting");
    }

    private static boolean isWifiConnected(Context c) {
        ConnectivityManager connManager = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mWifi = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);

        if (mWifi.isConnected()) {
            // Log.d("haha", "WIFI is connected");
            return true;
        } else {
            // Log.d("haha", "WIFI is not connected");
            return false;
        }
    }

    private static boolean isInternetConnected(Context c) {
        ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        if (ni == null) {
            return false;
        } else {
            return true;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    //full sync means to upload and download all possible data. Partial sync is uploading anything that changed locally but possibly without downloading
    //all possible data
    public boolean performSync() {
        Log.d("haha", "performing sync");

        boolean success = true;

        ProfileModel profileModel = ProfileModel.get();

        if (profileModel.denominationIdDirty) {
            JSONObject jo = API.setDenomination(profileModel.denominationId);

            try {
                if (jo != null && jo.has("status") && TextUtils.equals(jo.getString("status"), "ok")) {
                    profileModel.denominationIdDirty = false;
                } else {
                    success = false;
                }
            } catch (JSONException e) {
                success = false;
            }
        }

        if (success && profileModel.otherDenominationsEnabledDirty) {
            JSONObject jo = API.seeOtherDenominations(profileModel.otherDenominationsEnabled);

            try {
                if (jo != null && jo.has("status") && TextUtils.equals(jo.getString("status"), "true")) {
                    profileModel.otherDenominationsEnabledDirty = false;
                } else {
                    success = false;
                }
            } catch (JSONException e) {
                success = false;
            }
        }

        if (success && profileModel.notificationsEnabledDirty) {
            JSONObject jo = API.stopNotifications(!profileModel.notificationsEnabled);

            if (jo != null && jo.has("status")) {
                profileModel.notificationsEnabledDirty = false;
            } else {
                success = false;
            }
        }

        if (success && profileModel.uiLangIdDirty) {
            JSONObject jo = API.setUILanguage(profileModel.uiLangId);

            if (jo != null) {
                profileModel.uiLangIdDirty = false;
            } else {
                success = false;
            }

            if (jo != null && jo.has("UI_strings")) {
                try {
                    JSONObject uiStrings = jo.getJSONObject("UI_strings");

                    //save ui strings
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }

        if (success && profileModel.nameSurnameNickDirty) {
            JSONObject jo = API.updateName(profileModel.name, profileModel.surname, profileModel.nick);

            try {
                if (jo != null && jo.has("status") && jo.getBoolean("status")) {
                    profileModel.nameSurnameNickDirty = false;
                } else {
                    success = false;
                }
            } catch (JSONException e) {
                success = false;
            }
        }

        if (success && !TextUtils.equals(profileModel.myLanguagesIds, profileModel.myServerLanguagesIds)) {
            ArrayList<String> localSplit = new ArrayList<String>(Arrays.asList(profileModel.myLanguagesIds.split(",")));
            ArrayList<String> serverSplit = new ArrayList<String>(Arrays.asList(profileModel.myServerLanguagesIds.split(",")));

            for (String s : localSplit) {
                if (!TextUtils.isEmpty(s) && !serverSplit.contains(s)) {
                    int langID = Integer.parseInt(s);
                    JSONObject jo = API.setTextLanguage(langID, true);

                    if (jo == null || !jo.has("languages_added")) {
                        success = false;
                        break;
                    }
                }
            }

            if (success) {
                for (String s : serverSplit) {
                    if (!TextUtils.isEmpty(s) && !localSplit.contains(s)) {
                        int langID = Integer.parseInt(s);
                        JSONObject jo = API.setTextLanguage(langID, false);

                        if (jo == null || !jo.has("languages_removed")) {
                            success = false;
                            break;
                        }
                    }
                }
            }

            if (success) {
                profileModel.myServerLanguagesIds = profileModel.myLanguagesIds;
            }

        }

        profileModel.save(false);
        if (success) {
            List<GroupModel> groups = GroupModel.getTryingToJoin();

            for (GroupModel group : groups) {
                JSONObject obj = API.joinGroup(group.backendId, true);

                try {
                    if (obj != null && obj.has("status") && "true".equals(obj.getString("status"))) {
                        group.tryingToJoin = false;
                        group.persist();
                    } else {
                        success = false;
                        break;
                    }
                } catch (JSONException e) {
                    success = false;
                    break;
                }
            }
        }

        if (success) {
            List<GroupModel> groups = GroupModel.getTryingToLeave();

            for (GroupModel group : groups) {
                JSONObject obj = API.joinGroup(group.backendId, false);

                try {
                    if (obj != null && obj.has("status") && "true".equals(obj.getString("status"))) {
                        group.tryingToLeave = false;
                        group.persist();
                    } else {
                        success = false;
                        break;
                    }
                } catch (JSONException e) {
                    success = false;
                    break;
                }
            }
        }

        if (success) {
            List<TextModel> sharedTexts = TextModel.getShareTexts();

            for (TextModel text : sharedTexts) {
                if (text.isShared) {
                    JSONObject obj = API.shareText(text);

                    try {
                        if (obj != null && (obj.has("text_ID") || obj.has("New_text_ID"))) {

                            long id = 0;

                            if (obj.has("text_ID")) {
                                id = obj.getLong("text_ID");
                            }

                            if (obj.has("New_text_ID")) {
                                id = obj.getLong("New_text_ID");
                            }

                            text.backendId = id;
                            text.isShared = false;
                            text.isSharedDirty = false;
                            text.persist();
                        } else {
                            success = false;
                            break;
                        }
                    } catch (JSONException e) {
                        success = false;
                        break;
                    }
                }
            }
        }

        if (success) {
            List<GroupModel> newGroups = GroupModel.getNewGroups();

            for (GroupModel group : newGroups) {
                JSONObject obj = API.createGroup(group.langId, group.name, group.description, group.isPrivate, group.myDenomination);

                try {
                    if (obj == null || !obj.has("status") || obj.isNull("status") || !obj.getBoolean("status")) {
                        success = false;
                    } else {
                        long id = 0;

                        if (obj.has("ID")) {
                            id = obj.getLong("ID");
                        } else if (obj.has("group_exists")) {
                            id = obj.getLong("group_exists");
                        }

                        group.backendId = id;
                        group.delete();
                        group.id = null;
                        group.persist();
                    }
                } catch (JSONException e) {
                    success = false;
                }

            }
        }

        if (success) {
            List<NotificationModel> newNotifications = NotificationModel.getNewNotifications();

            for (NotificationModel notif : newNotifications) {
                JSONObject obj = API.sendNotification(notif.groupId, notif.message);

                try {
                    if (obj == null || !obj.has("status") || obj.isNull("status")) { //|| !obj.getBoolean("status")) {
                        success = false;
                    } else {
                        long id = 0;

                        if (obj.has("notification_ID")) {
                            id = obj.getLong("notification_ID");
                        } else if (obj.has("message_exists")) {
                            id = obj.getLong("message_exists");
                        }

                        notif.backendId = id;
                        notif.delete();
                        notif.id = null;
                        notif.persist();
                    }
                } catch (JSONException e) {
                    success = false;
                }
            }
        }

        if (success) {
            List<NotificationModel> deleted = NotificationModel.getDeletedNotifications();
            if (deleted.size() > 0) {
                JSONObject obj = API.deleteNotifications(deleted);

                if (obj != null) {
                    for (NotificationModel n : deleted) {
                        n.delete();
                    }
                } else {
                    success = false;
                }
            }
        }

        if (success) {
            List<TextModel> likeTexts = TextModel.getLikeTexts();
            List<NotificationModel> likeNotifications = NotificationModel.getLikeNotifications();

            List<TextUsageModel> usages = TextUsageModel.getAllTextUsages();

            JSONObject jo = API.sync(likeTexts, likeNotifications, usages);

            if (jo != null) {
                try {
                    handleSyncResult(jo);

                    for (TextModel model : likeTexts) {
                        model.likeDirty = false;
                        model.persist();
                    }

                    for (NotificationModel model : likeNotifications) {
                        model.likeDirty = false;
                        model.persist();
                    }

                    for (TextUsageModel usage : usages) {
                        usage.delete();
                    }

                } catch (JSONException e) {
                    Log.d("haha", "sync exception: ", e);
                    success = false;
                }
            } else {
                success = false;
            }
        }

        if (success) {
            JSONObject result = API.syncTime(System.currentTimeMillis() / 1000);

            try {
                if (result == null || !result.has("status") || result.isNull("status") || !result.getString("status").equals("true")) {
                    success = false;
                }
            } catch (JSONException e) {
                success = false;
            }

        }

        return success;
    }

    public static void handleSyncResult(JSONObject syncResult) throws JSONException {
        if (syncResult == null) {
            return;
        }

        JSONArray langs = syncResult.getJSONArray("Langs");

        JSONArray groups = null;
        JSONObject groupsObject = null;

        try {
            groups = syncResult.getJSONArray("Groups");
        } catch (JSONException e) {
            groupsObject = syncResult.getJSONObject("Groups");
        }

        JSONArray texts = syncResult.getJSONArray("Texts");
        JSONArray notifications = syncResult.getJSONArray("Notifications");
        JSONArray notificationsCounter = syncResult.getJSONArray("My_notifications_counter");

        List<LanguageModel> languageList = new ArrayList<LanguageModel>();
        for (int i = 0; i < langs.length(); i++) {
            JSONObject d = langs.getJSONObject(i);
            LanguageModel dm = new LanguageModel();

            dm.backendId = d.getLong("ID");
            dm.code = d.getString("Code");
            dm.name = d.getString("Lang_name");
            dm.description = d.getString("Description");
            dm.uiStrings = d.getString("UI_strings").equals("false") ? false : true;

            languageList.add(dm);
        }
        LanguageModel.replaceAll(languageList);


        List<GroupModel> groupList = new ArrayList<GroupModel>();
        for (int i = 0; i < (groups != null ? groups.length() : groupsObject.names().length()); i++) {

            JSONObject d = null;

            if (groups != null) {
                d = groups.getJSONObject(i);
            } else {
                d = groupsObject.getJSONObject(groupsObject.names().getString(i));
            }

            GroupModel dm = new GroupModel();

            dm.backendId = d.getLong("ID");
            dm.name = d.getString("Group_name");
            dm.description = d.getString("Description");
            dm.langId = d.getLong("Lang");
            //dm.denomination = d.getString("Denomination");
            dm.creationDate = d.getString("create_date");
            dm.isPrivate = d.getInt("is_private") != 0;
            dm.joined = d.isNull("joined") ? null : d.getString("joined");
            dm.admin = d.getBoolean("admin");
            dm.invited = d.getString("invited");
            dm.memberCount = d.has("member_count") ? d.getInt("member_count") : 0;

            groupList.add(dm);
        }
        GroupModel.replaceAll(groupList);

        List<TextModel> textModels = new ArrayList<TextModel>();
        for (int i = 0; i < texts.length(); i++) {
            JSONObject d = texts.getJSONObject(i);
            TextModel tm = new TextModel();

            tm.backendId = d.getLong("ID");
            tm.langId = d.getLong("Lang");
            tm.text = d.getString("String");
            tm.title = d.getString("Description");
            tm.schedule = d.getString("Schedule");
            tm.rating = d.isNull("T_Rating") ? null : d.getInt("T_Rating");
            tm.code = d.isNull("Code") ? "" : d.getString("Code");
            tm.type = d.getInt("Text_type");

            textModels.add(tm);
        }
        TextModel.updateAll(textModels, false);

        List<NotificationModel> notificationModels = new ArrayList<NotificationModel>();
        for (int i = 0; i < notifications.length(); i++) {
            JSONObject d = notifications.getJSONObject(i);
            NotificationModel nm = new NotificationModel();

            nm.backendId = d.getLong("ID");
            nm.message = d.getString("Notification");
            nm.groupId = d.isNull("Group_ID") ? null : d.getLong("Group_ID");
            nm.rating = d.getInt("Rating");
            nm.date = d.getString("Create_date");
            nm.valid = d.getInt("Valid") != 0;
            nm.userId = d.isNull("User") ? null : d.getLong("User");
            nm.userNick = d.getString("Nick");

            if (d.has("MYLikes") && !d.isNull("MYLikes")) {
                String mylikes = d.getString("MYLikes");

                Log.d("haha", "mylikes: " + mylikes);

                if ("1".equals(mylikes)) {
                    nm.like = true;
                } else {
                    nm.like = false;
                }
            }

            notificationModels.add(nm);
        }
        NotificationModel.updateAll(notificationModels, false);

        if (ProfileModel.get().loggedIn && notificationModels.size() > 0) {
            AlarmReceiver.showNotification(MyApplication.get(), (int) (notificationModels.get(0).backendId + 0), null, "Convocatis notification", "You have new notifications", false);
        }

        notificationModels = NotificationModel.getAllNotifications();

        for (int i = 0; i < notificationsCounter.length(); i++) {
            JSONObject d = notificationsCounter.getJSONObject(i);

            long id = d.getLong("ID");
            int counter = d.getInt("Counter");
            int rating = d.getInt("Rating");

            for (int j = 0; j < notificationModels.size(); j++) {
                NotificationModel nm = notificationModels.get(j);

                if (nm.backendId != null && nm.backendId == id) {
                    nm.id = null;
                    nm.counter = counter;
                    nm.rating = rating;
                    nm.persist();
                }
            }
        }


    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        if (TextUtils.isEmpty(ProfileModel.get().email)) {
            if (!mSynchronizationPending) {
                stopSelf();
            }
            return Service.START_STICKY;
        }

        if (intent == null) {
            return Service.START_STICKY;
        }
        boolean intentFullSync = intent.getExtras().getBoolean("full_sync");

        setAlarm(this);
        if (mSynchronizationPending) {
            Log.d("haha", "ENABLING SHOULD PERFORM");
            mShouldPerformAnotherSync = true;
            if (intentFullSync) {
                mShouldPerformAnotherSyncFullSync = true;
            }
            return Service.START_STICKY;
        }
        mShouldPerformAnotherSync = false;
        mShouldPerformAnotherSyncFullSync = false;

        mFullSync = intentFullSync;
        //this is where we consider synchronisation as started
        mSynchronizationPending = true;

        if (mOnSynchronizationFinishedListener != null) {
            mOnSynchronizationFinishedListener.onSynchronizationStarted(mFullSync);
        }
        if (!isInternetConnected(this)) {
            mSynchronizationPending = false;
            if (mOnSynchronizationFinishedListener != null) {
                mOnSynchronizationFinishedListener.onSynchronizationFinished(mFullSync, false);
            }
            stopSelf();
            return Service.START_STICKY;
        }
        new DiskTask() {

            boolean success;

            @Override
            public void getData() {
                try {
                    success = performSync();
                } catch (Exception e) {
                    Log.d("haha", "sync exception: ", e);
                }
            }

            @Override
            public void onDataReceived() {
                Log.d("haha", "sync completed");

                mSynchronizationPending = false;
                if (mOnSynchronizationFinishedListener != null) {
                    mOnSynchronizationFinishedListener.onSynchronizationFinished(mFullSync, success);
                }

                if (mShouldPerformAnotherSync) {
                    Log.d("haha", "should perform another");
                    startSync(mShouldPerformAnotherSyncFullSync);
                } else {
                    stopSelf();
                }
            }
        }.execute();

        return Service.START_STICKY;
    }

    public static void startSync(boolean fullSync) {
        Intent intent = new Intent(MyApplication.get(), SynchronizationService.class);
        intent.putExtra("full_sync", fullSync);
        MyApplication.get().startService(intent);
    }

    private void setAlarm(Context context) {

        cancelAlarm(context);

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, SynchronizationService.class);

        PendingIntent pi = PendingIntent.getService(context, 0, intent, 0);
        am.setRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 3600 * 1000, 3600 * 1000, pi);
    }

    private void cancelAlarm(Context context) {
        Intent intent = new Intent(context, SynchronizationService.class);

        PendingIntent pi = PendingIntent.getService(context, 0, intent, 0);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmManager.cancel(pi);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        Log.d("haha", "service is stopping");
    }

}
