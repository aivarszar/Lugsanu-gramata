package net.convocatis.convocatis.database.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import net.convocatis.convocatis.MyApplication;
import net.convocatis.convocatis.database.Database;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by reactor on 1/24/16.
 */
@DatabaseTable(tableName = "text_usages")
public class TextUsageModel {
    @DatabaseField(generatedId = true)
    public Long id;
    @DatabaseField
    public Long start;
    @DatabaseField
    public Long end;
    @DatabaseField
    public String notificationIds;
    @DatabaseField
    public Long textId;


    public void delete() {
        Database database = MyApplication.getDB();
        try {
            database.textUsages.delete(this);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void persist() {

        Database database = MyApplication.getDB();

        try {
            database.textUsages.createOrUpdate(this);
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    public static void clearAll() {
        MyApplication.getDB().clearTable(TextUsageModel.class);
    }



    public static List<TextUsageModel> getAllTextUsages() {
        try {
            return MyApplication.getDB().textUsages.queryForAll();
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

}
