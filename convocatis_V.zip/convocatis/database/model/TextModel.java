package net.convocatis.convocatis.database.model;

import android.text.TextUtils;
import android.util.Log;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import net.convocatis.convocatis.MyApplication;
import net.convocatis.convocatis.database.Database;
import net.convocatis.convocatis.utils.Utils;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by reactor on 1/24/16.
 */
@DatabaseTable(tableName = "texts")
public class TextModel implements Serializable, Cloneable {
    @DatabaseField(generatedId = true)
    public Long id;
    @DatabaseField
    public Long backendId;
    @DatabaseField
    public Long originalId;
    @DatabaseField
    public Boolean isShared;
    @DatabaseField
    public String text;
    @DatabaseField
    public String title;
    @DatabaseField
    public Long langId;
    @DatabaseField
    public Boolean like;
    @DatabaseField
    public String code;
    @DatabaseField
    public Integer type;
    @DatabaseField
    public Integer rating;
    @DatabaseField
    public boolean highlighted;
    @DatabaseField
    public Boolean isDefault;
    @DatabaseField
    public String schedule;

    @DatabaseField
    public boolean dirty;
    @DatabaseField
    public boolean likeDirty;
    @DatabaseField
    public boolean scheduleDirty;
    @DatabaseField
    public boolean isSharedDirty;

    public boolean expanded;

    public void delete()
    {
        Database database = MyApplication.getDB();
        try {
            database.texts.delete(this);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void persist() {

        Database database = MyApplication.getDB();

        try {

            if (backendId != null && id == null) {
                List<TextModel> foundList = database.texts.queryForEq("backendId", backendId);
                TextModel foundModel = null;

                if (foundList.size() > 0) {
                    foundModel = foundList.get(0);
                }

                if (foundModel != null) {
                    id = foundModel.id;
                    highlighted = foundModel.highlighted;
                    schedule = foundModel.schedule;
                    dirty = foundModel.dirty;
                    like = foundModel.like;
                    likeDirty = foundModel.likeDirty;
                    scheduleDirty = foundModel.scheduleDirty;
                    isSharedDirty = foundModel.isSharedDirty;
                }
            }

            database.texts.createOrUpdate(this);


        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    public static void updateAll(List<TextModel> list, boolean withClear) {

        if (withClear) {
            MyApplication.getDB().clearTable(TextModel.class);
        }

        for (TextModel model : list) {
            model.persist();
        }

        Log.d("haha", "updated " + list.size() + " texts");
    }

    public static List<TextModel> getAllTexts() {
        try {
            return MyApplication.getDB().texts.queryForAll();
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    public static List<TextModel> getHighlightedTexts() {
        try {
            return MyApplication.getDB().texts.queryForEq("highlighted", true);
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    public static List<TextModel> getLikeTexts() {
        try {
            return MyApplication.getDB().texts.queryForEq("likeDirty", true);
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    public static List<TextModel> getShareTexts() {
        try {
            return MyApplication.getDB().texts.queryForEq("isSharedDirty", true);
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    public static void clearAll() {
        MyApplication.getDB().clearTable(TextModel.class);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public String getNextPrayerTimeString() {
        long o = getNextPrayerTime();

        if (o == -1) {
            return "no prayer";
        } else {
            return Utils.dateTimeToString(new Date(o));
        }
    }

    public long getNextPrayerTime() {
        try {
            long now = System.currentTimeMillis();
            long time = -1;

            if (TextUtils.isEmpty(schedule)) {
                return time;
            }

            String[] split = schedule.split(";", Integer.MAX_VALUE);

            if (split.length != 6) {
                return time;
            }

            Date beginDate = Utils.dateTimeFromString(split[0]);
            Date endDate = null;

            if (!TextUtils.isEmpty(split[5])) {
                endDate = Utils.dateFromString(split[5]);
            }

            Calendar beginDateCalendar = Calendar.getInstance();
            int beginDayOfWeek = beginDateCalendar.get(Calendar.DAY_OF_WEEK);
            int beginDayOfMonth = beginDateCalendar.get(Calendar.DAY_OF_MONTH);
            int beginDayOfYear = beginDateCalendar.get(Calendar.DAY_OF_YEAR);
            beginDateCalendar.setTime(beginDate);

            int maxRepetitions = 0;

            if (!TextUtils.isEmpty(split[4])) {
                maxRepetitions = Integer.parseInt(split[4]);
            }

            int repeatEvery = Integer.parseInt(split[1]);

            if (repeatEvery <= 0) {
                repeatEvery = 1;
            }


            String unitOfTime = split[2];

            List<String> weekDays = new ArrayList<String>();

            if (!TextUtils.isEmpty(split[3])) {
                weekDays = Arrays.asList(split[3].split(","));
            }

            Calendar date = Calendar.getInstance();
            int weekNumber = -1;
            int monthNumber = -1;
            int yearNumber = -1;
            int repetitions = 0;

            for (long dayNumber = 0; ; dayNumber++) {
                date.setTime(new Date(beginDate.getTime() + dayNumber * 3600 * 24 * 1000));
                int dayOfWeek = date.get(Calendar.DAY_OF_WEEK);
                int dayOfMonth = date.get(Calendar.DAY_OF_MONTH);
                int dayOfYear = date.get(Calendar.DAY_OF_YEAR);

                if (endDate != null && endDate.getTime() < Utils.dateFromString(Utils.dateTimeToString(date.getTime())).getTime()) {
                    break;
                }

                if (unitOfTime.equals("d")) {
                    if (dayNumber % repeatEvery > 0) {
                        continue;
                    }

                    repetitions++;
                    if (date.getTime().getTime() > now) {
                        time = date.getTime().getTime();
                        break;
                    }
                }

                if (dayOfWeek == beginDayOfWeek) {
                    weekNumber++;
                }

                if (dayOfMonth == beginDayOfMonth) {
                    monthNumber++;

                    if (unitOfTime.equals("m")) {
                        if (monthNumber % repeatEvery > 0) {
                            continue;
                        }


                        repetitions++;
                        if (date.getTime().getTime() > now) {
                            time = date.getTime().getTime();
                            break;
                        }
                    }
                }

                if (dayOfYear == beginDayOfYear) {
                    yearNumber++;

                    if (unitOfTime.equals("y")) {
                        if (yearNumber % repeatEvery > 0) {
                            continue;
                        }

                        repetitions++;
                        if (date.getTime().getTime() > now) {
                            time = date.getTime().getTime();
                            break;
                        }

                    }
                }

                if (unitOfTime.equals("w")) {
                    if (weekNumber % repeatEvery > 0) {
                        continue;
                    }

                    boolean hit = false;
                    switch (dayOfWeek) {
                        case 1:
                            if (weekDays.contains("sun")) {
                                hit = true;
                            }
                            break;
                        case 2:
                            if (weekDays.contains("mon")) {
                                hit = true;
                            }
                            break;
                        case 3:
                            if (weekDays.contains("tue")) {
                                hit = true;
                            }
                            break;
                        case 4:
                            if (weekDays.contains("wed")) {
                                hit = true;
                            }
                            break;
                        case 5:
                            if (weekDays.contains("thu")) {
                                hit = true;
                            }
                            break;
                        case 6:
                            if (weekDays.contains("fri")) {
                                hit = true;
                            }
                            break;
                        case 7:
                            if (weekDays.contains("sat")) {
                                hit = true;
                            }
                            break;
                    }

                    if (hit) {
                        repetitions++;
                        if (date.getTime().getTime() > now) {
                            time = date.getTime().getTime();
                            break;
                        }
                    }
                }

                if (maxRepetitions > 0 && repetitions > maxRepetitions) {
                    break;
                }
            }


            return time;
        } catch (Exception e) {
            return -1;
        }
    }

}
