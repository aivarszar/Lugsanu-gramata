package net.convocatis.convocatis.database.model;

import android.util.Log;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;
import com.j256.ormlite.table.TableUtils;

import net.convocatis.convocatis.MyApplication;
import net.convocatis.convocatis.database.Database;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by reactor on 1/24/16.
 */
@DatabaseTable(tableName = "denominations")
public class DenominationModel {
    @DatabaseField(generatedId = true)
    public Long id;
    @DatabaseField
    public Long backendId;
    @DatabaseField
    public String name;
    @DatabaseField
    public String type;
    @DatabaseField
    public Integer religion;
    @DatabaseField
    public String description;

    public void persist() {
        try {
            MyApplication.getDB().denominations.createOrUpdate(this);
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    public static void replaceAll(List<DenominationModel> list) {
        MyApplication.getDB().clearTable(DenominationModel.class);

        for (DenominationModel model : list) {
            model.persist();
        }
    }

    public static List<DenominationModel> getAllDenominations() {
        try {
            return MyApplication.getDB().denominations.queryForAll();
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }
}
