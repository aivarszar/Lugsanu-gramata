package net.convocatis.convocatis.database.model;

import android.util.Log;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import net.convocatis.convocatis.MyApplication;
import net.convocatis.convocatis.database.Database;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by reactor on 1/24/16.
 */
@DatabaseTable(tableName = "notifications")
public class NotificationModel {
    @DatabaseField(generatedId = true)
    public Long id;
    @DatabaseField
    public Long backendId;
    @DatabaseField
    public Boolean like;
    @DatabaseField
    public boolean hidden;
    @DatabaseField
    public String message;
    @DatabaseField
    public String userNick;
    @DatabaseField
    public Long userId;
    @DatabaseField
    public Long groupId;
    @DatabaseField
    public Integer rating;
    @DatabaseField
    public Integer counter;
    @DatabaseField
    public Boolean valid;
    @DatabaseField
    public String date;
    @DatabaseField
    public Boolean highlighted;

    @DatabaseField
    public boolean dirty;
    @DatabaseField
    public boolean likeDirty;
    @DatabaseField
    public boolean deleted;

    public boolean expanded;

    public void delete()
    {
        Database database = MyApplication.getDB();
        try {
            database.notifications.delete(this);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void persist() {

        Database database = MyApplication.getDB();

        try {
            if (backendId != null && backendId != -1 && id == null) {
                List<NotificationModel> foundList = database.notifications.queryForEq("backendId", backendId);
                NotificationModel foundModel = null;

                if (foundList.size() > 0) {
                    foundModel = foundList.get(0);
                }

                if (foundModel != null) {
                    id = foundModel.id;
                    highlighted = foundModel.highlighted;
                    like = foundModel.like;
                    dirty = foundModel.dirty;
                    deleted = foundModel.deleted;
                    likeDirty = foundModel.likeDirty;

                }
            }

            database.notifications.createOrUpdate(this);

        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    public static void updateAll(List<NotificationModel> list, boolean withClear) {

        if (withClear) {
            MyApplication.getDB().clearTable(NotificationModel.class);
        }

        for (NotificationModel model : list) {
            model.persist();
        }

        Log.d("haha", "updated " + list.size() + " notifications");
    }

    public static List<NotificationModel> getAllNotifications() {
        try {
            return MyApplication.getDB().notifications.queryForEq("deleted", false);
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    public static List<NotificationModel> getDeletedNotifications() {
        try {
            return MyApplication.getDB().notifications.queryForEq("deleted", true);
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    public static void clearAll() {
        MyApplication.getDB().clearTable(NotificationModel.class);
    }

    public static List<NotificationModel> getLikeNotifications() {
        try {
            return MyApplication.getDB().notifications.queryForEq("likeDirty", true);
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    public static List<NotificationModel> getUnhiddenNotifications() {
        try {
            return MyApplication.getDB().notifications.queryForEq("hidden", false);
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    public static List<NotificationModel> getNewNotifications() {
        try {
            return MyApplication.getDB().notifications.queryForEq("backendId", -1);
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

}
