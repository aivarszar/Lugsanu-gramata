package net.convocatis.convocatis.database.model;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.gson.annotations.Expose;

import net.convocatis.convocatis.MyApplication;
import net.convocatis.convocatis.networking.SynchronizationService;

import org.json.JSONObject;

/**
 * Created by reactor on 1/24/16.
 */
public class ProfileModel implements Cloneable {

    private static final String PREFS_PROFILE_MODEL = "PREFS_PROFILE_MODEL";
    private static ProfileModel sProfileModel;

    @Expose
    public String email;
    @Expose
    public String name;
    @Expose
    public String surname;
    @Expose
    public String nick;
    @Expose
    public Long syncTime;
    @Expose
    public Boolean notificationsEnabled;
    @Expose
    public Boolean otherDenominationsEnabled;
    @Expose
    public Long uiLangId;
    @Expose
    public String myLanguagesIds;
    @Expose
    public String myServerLanguagesIds;
    @Expose
    public Long denominationId;
    @Expose
    public Long themeId;

    @Expose
    public boolean emailDirty;
    @Expose
    public boolean nameSurnameNickDirty;
    @Expose
    public boolean syncTimeDirty;
    @Expose
    public boolean notificationsEnabledDirty;
    @Expose
    public boolean otherDenominationsEnabledDirty;
    @Expose
    public boolean uiLangIdDirty;
    @Expose
    public boolean denominationIdDirty;
    @Expose
    public boolean themeIdDirty;

    @Expose
    public boolean loggedIn;

    @Expose
    public Long id;
    @Expose
    public Integer verified;
    @Expose
    public Integer hasNews;
    @Expose
    public String invString;
    @Expose
    public Integer authService;
    @Expose
    public Integer sponsor;

    public static void clearWithSave() {
        sProfileModel = new ProfileModel();
        save(false);
    }

    public static ProfileModel get() {

        if (sProfileModel == null) {
            SharedPreferences sharedPrefs = MyApplication.get().getSharedPreferences(PREFS_PROFILE_MODEL, Context.MODE_PRIVATE);
            String json = sharedPrefs.getString(PREFS_PROFILE_MODEL, null);

            if (json == null) {
                sProfileModel = new ProfileModel();
            } else {
                sProfileModel = MyApplication.getGson().fromJson(json, ProfileModel.class);

                if (sProfileModel == null) {
                    sProfileModel = new ProfileModel();
                }
            }

        }

        return sProfileModel;
    }

    public static void save() {
        save(true);
    }

    public static void save(boolean startSync) {
        if (sProfileModel == null) {
            return;
        }

        SharedPreferences.Editor editor = MyApplication.get().getSharedPreferences(PREFS_PROFILE_MODEL, Context.MODE_PRIVATE).edit();
        editor.putString(PREFS_PROFILE_MODEL, MyApplication.getGson().toJson(sProfileModel));
        editor.commit();

        if (startSync) {
            SynchronizationService.startSync(false);
        }
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
