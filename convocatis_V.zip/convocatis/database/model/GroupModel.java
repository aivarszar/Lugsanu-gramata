package net.convocatis.convocatis.database.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import net.convocatis.convocatis.MyApplication;
import net.convocatis.convocatis.database.Database;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by reactor on 1/24/16.
 */
@DatabaseTable(tableName = "groups")
public class GroupModel {
    @DatabaseField(generatedId = true)
    public Long id;
    @DatabaseField
    public Long backendId;
    @DatabaseField
    public String name;
    @DatabaseField
    public String description;
    @DatabaseField
    public Long langId;
    @DatabaseField
    public Boolean myDenomination;
    @DatabaseField
    public String creationDate;
    @DatabaseField
    public Boolean isPrivate;
    @DatabaseField
    public String joined;
    @DatabaseField
    public Boolean admin;
    @DatabaseField
    public String invited;
    @DatabaseField
    public Integer memberCount;

    @DatabaseField
    public boolean tryingToJoin;
    @DatabaseField
    public boolean tryingToLeave;

    public boolean expanded;

    public void delete()
    {
        Database database = MyApplication.getDB();
        try {
            database.groups.delete(this);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void persist() {

        Database database = MyApplication.getDB();

        try {
            if (backendId != null && backendId != -1 && id == null) {
                List<GroupModel> foundList = database.groups.queryForEq("backendId", backendId);
                GroupModel foundModel = null;

                if (foundList.size() > 0) {
                    foundModel = foundList.get(0);
                }

                if (foundModel != null) {
                    id = foundModel.id;
                    tryingToJoin = foundModel.tryingToJoin;
                    tryingToLeave = foundModel.tryingToLeave;
                }
            }

            database.groups.createOrUpdate(this);

        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    public static void clearAll() {
        MyApplication.getDB().clearTable(GroupModel.class);
    }

    public static void replaceAll(List<GroupModel> list) {
        for (GroupModel model : list) {
            model.persist();
        }
    }

    public static List<GroupModel> getAllGroups() {
        try {
            return MyApplication.getDB().groups.queryForAll();
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    public static List<GroupModel> getTryingToJoin() {
        try {
            return MyApplication.getDB().groups.queryForEq("tryingToJoin", true);
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    public static List<GroupModel> getTryingToLeave() {
        try {
            return MyApplication.getDB().groups.queryForEq("tryingToLeave", true);
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    public static List<GroupModel> getNewGroups() {
        try {
            return MyApplication.getDB().groups.queryForEq("backendId", -1);
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }


}
