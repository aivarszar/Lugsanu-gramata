package net.convocatis.convocatis.database.model;

import android.util.Log;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import net.convocatis.convocatis.MyApplication;
import net.convocatis.convocatis.database.Database;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by reactor on 1/24/16.
 */
@DatabaseTable(tableName = "languages")
public class LanguageModel {
    @DatabaseField(generatedId = true)
    public Long id;
    @DatabaseField
    public Long backendId;
    @DatabaseField
    public String code;
    @DatabaseField
    public String name;
    @DatabaseField
    public String description;
    @DatabaseField
    public Boolean uiStrings;


    public void persist() {

        Database database = MyApplication.getDB();

        try {
            if (backendId != null) {
                List<LanguageModel> foundList = database.languages.queryForEq("backendId", backendId);
                LanguageModel foundModel = null;

                if (foundList.size() > 0) {
                    foundModel = foundList.get(0);
                }

                if (foundModel != null) {
                    id = foundModel.id;
                }
            }

            database.languages.createOrUpdate(this);


        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    public static void replaceAll(List<LanguageModel> list) {
        for (LanguageModel model : list) {
            Log.d("haha", "adding language: " + model.backendId + " " + model.name);
            model.persist();
        }
    }

    public static void clearAll() {
        MyApplication.getDB().clearTable(LanguageModel.class);
    }

    public static List<LanguageModel> getAllLanguagesWithUIStrings() {
        try {
            return MyApplication.getDB().languages.queryForEq("uiStrings", true);
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    public static List<LanguageModel> getAllLanguages() {
        try {
            return MyApplication.getDB().languages.queryForAll();
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }
}
