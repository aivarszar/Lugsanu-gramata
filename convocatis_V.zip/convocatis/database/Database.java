package net.convocatis.convocatis.database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.ReferenceObjectCache;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;

import net.convocatis.convocatis.database.model.DenominationModel;
import net.convocatis.convocatis.database.model.GroupModel;
import net.convocatis.convocatis.database.model.LanguageModel;
import net.convocatis.convocatis.database.model.NotificationModel;
import net.convocatis.convocatis.database.model.ProfileModel;
import net.convocatis.convocatis.database.model.TextModel;
import net.convocatis.convocatis.database.model.TextUsageModel;

import java.sql.SQLException;
import java.util.List;

public class Database {

    private static final String TAG = Database.class.getCanonicalName();
    private static String DB_NAME = "database";

    private static int DB_VERSION = 1;
    private Helper helper;

    public ProfileModel mProfileModel;

    public final Dao<DenominationModel, Long> denominations;
    public final Dao<GroupModel, Long> groups;
    public final Dao<LanguageModel, Long> languages;
    public final Dao<NotificationModel, Long> notifications;
    public final Dao<TextModel, Long> texts;
    public final Dao<TextUsageModel, Long> textUsages;

    public Database(Context context) {
        helper = new Helper(context, DB_NAME, null, DB_VERSION);
        try {
            denominations = helper.getDao(DenominationModel.class);
            groups = helper.getDao(GroupModel.class);
            languages = helper.getDao(LanguageModel.class);
            notifications = helper.getDao(NotificationModel.class);
            texts = helper.getDao(TextModel.class);
            textUsages = helper.getDao(TextUsageModel.class);

//            denominations.setObjectCache(ReferenceObjectCache.makeSoftCache());
//            groups.setObjectCache(ReferenceObjectCache.makeSoftCache());
//            languages.setObjectCache(ReferenceObjectCache.makeSoftCache());
//            notifications.setObjectCache(ReferenceObjectCache.makeSoftCache());
//            texts.setObjectCache(ReferenceObjectCache.makeSoftCache());
//            textUsages.setObjectCache(ReferenceObjectCache.makeSoftCache());
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }

    }

    private static class Helper extends OrmLiteSqliteOpenHelper {

        private static Class[] tableClasses = new Class[]{DenominationModel.class, GroupModel.class,
                LanguageModel.class, NotificationModel.class, TextModel.class, TextUsageModel.class};

        public Helper(Context context, String name, SQLiteDatabase.CursorFactory factory,
                      int version) {
            super(context, name, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db, ConnectionSource connectionSource) {
            Log.d(TAG, "onCreate()");
            try {
                for (Class c : tableClasses)
                    TableUtils.createTable(connectionSource, c);
            } catch (SQLException e) {
                Log.e(TAG, "Can't create database", e);
                throw new RuntimeException(e);
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, ConnectionSource connectionSource, int oldVersion, int newVersion) {
            Log.d(TAG, "onUpgrade()");
            Cursor tables = db.query("sqlite_master", new String[]{"tbl_name"}, "type=\'table\'", null, null, null, null);
            if (tables.moveToFirst()) {
                while (!tables.isAfterLast()) {
                    String tableName = tables.getString(0);
                    if (!(tableName.startsWith("android_") || tableName.startsWith("sqlite_"))) {
                        Log.d(TAG, "Dropping table " + tableName);
                        db.execSQL("DROP TABLE " + tableName);
                    }
                    tables.moveToNext();
                }
            }
            onCreate(db, connectionSource);
        }
    }


    public void clearDatabase()
    {

    }

    public void clearTable(Class dataClass) {
        try {
            TableUtils.clearTable(helper.getConnectionSource(), dataClass);
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }
}
