package net.convocatis.convocatis.ui;

import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.FacebookSdk;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

import net.convocatis.convocatis.R;
import net.convocatis.convocatis.database.model.ProfileModel;
import net.convocatis.convocatis.database.model.TextModel;
import net.convocatis.convocatis.receivers.AlarmReceiver;
import net.convocatis.convocatis.ui.fragments.GroupNewFragment;
import net.convocatis.convocatis.ui.fragments.GroupsFragment;
import net.convocatis.convocatis.ui.fragments.LoginFragment;
import net.convocatis.convocatis.ui.fragments.MessageToAdminFragment;
import net.convocatis.convocatis.ui.fragments.NotificationNewFragment;
import net.convocatis.convocatis.ui.fragments.NotificationsFragment;
import net.convocatis.convocatis.ui.fragments.ProfileFragment;
import net.convocatis.convocatis.ui.fragments.ReportBugFragment;
import net.convocatis.convocatis.ui.fragments.TextEditFragment;
import net.convocatis.convocatis.ui.fragments.TextReadingFragment;
import net.convocatis.convocatis.ui.fragments.TextsFragment;

public class MainActivity extends AppCompatActivity {

    //sync not returning mylike for texts
    //text sharing not returning text id
    //notif sharing not returning notif id if notif already exists

    private NavigationView mNavigationView;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private boolean mActivityResumed;
    private MenuItem mShowNavigationItem;
    private SearchView mSearchView;
    private MenuItem mSearchMenuItem;

    private MenuItem mSortBySchedule, mSortAlpha, mShowHighlighted;

    private TextView mMenuTexts, mMenuNotifs, mMenuGroups;

    private View mMenuLayout;

    private AdRequest adRequest;

    public interface OnSearchTermChangedListener {
        void onSearchTermChanged(String searchTerm);

        void onSearchStarted();

        void onSearchStopped();
    }

    private OnSearchTermChangedListener mOnSearchTermChangedListener;

    public void setOnSearchTermChangedListener(OnSearchTermChangedListener onSearchTermChangedListener) {
        mOnSearchTermChangedListener = onSearchTermChangedListener;
    }

    private static Fragment mCurrentFragment;

    public interface OnActivityResultListener {
        void onActivityResultCalled(int requestCode, int resultCode, Intent data);
    }

    private OnActivityResultListener mOnActivityResultListener;

    public void setOnActivityResultListener(OnActivityResultListener onActivityResultListener) {
        mOnActivityResultListener = onActivityResultListener;
    }

    public interface OnOptionsItemSelectedFragmentListener {
        void onOptionsItemSelectedFragment(MenuItem item);
    }

    private OnOptionsItemSelectedFragmentListener mOnOptionsItemSelectedFragmentListener;

    public void setOnOptionsItemSelectedListener(OnOptionsItemSelectedFragmentListener onOptionsItemSelectedFragmentListener) {
        mOnOptionsItemSelectedFragmentListener = onOptionsItemSelectedFragmentListener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getSupportActionBar().setElevation(0);

        FacebookSdk.sdkInitialize(getApplicationContext());

        setContentView(R.layout.activity_main);

        mMenuLayout = findViewById(R.id.menu_layout);

        mMenuTexts = (TextView) findViewById(R.id.menu_texts);
        mMenuNotifs = (TextView) findViewById(R.id.menu_notif);
        mMenuGroups = (TextView) findViewById(R.id.menu_groups);

        mMenuTexts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchToTextsFragment(false);
                mDrawerLayout.closeDrawer(mNavigationView);
            }
        });

        mMenuNotifs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchToNotificationsFragment(false);
                mDrawerLayout.closeDrawer(mNavigationView);
            }
        });

        mMenuGroups.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(ProfileModel.get().nick)) {
                    switchToGroupsFragment(false);
                    mDrawerLayout.closeDrawer(mNavigationView);
                } else {
                    Toast.makeText(MainActivity.this, "Please set your nick to access groups.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        mNavigationView = (NavigationView) findViewById(R.id.navigation_view);
        mNavigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                switch (menuItem.getItemId()) {
                    case R.id.navigation_item_profile:
                        mDrawerLayout.closeDrawer(mNavigationView);
                        switchToProfileFragment(false);
                        return true;
//                    case R.id.navigation_item_texts:
//                        mDrawerLayout.closeDrawer(mNavigationView);
//                        switchToTextsFragment(false);
//                        return true;
//                    case R.id.navigation_item_notifications:
//                        mDrawerLayout.closeDrawer(mNavigationView);
//                        switchToNotificationsFragment(false);
//                        return true;
//                    case R.id.navigation_item_groups:
//                        mDrawerLayout.closeDrawer(mNavigationView);
//                        if (!TextUtils.isEmpty(ProfileModel.get().nick)) {
//                            switchToGroupsFragment(false);
//                        } else {
//                            Toast.makeText(MainActivity.this, "Please set your nick to access groups.", Toast.LENGTH_SHORT).show();
//                        }
//
//                        return true;
//                    case R.id.navigation_item_send_message:
//                        mDrawerLayout.closeDrawer(mNavigationView);
//                        switchToMessageToAdminFragment(false);
//                        return true;
                    case R.id.navigation_item_report_bug:
                        mDrawerLayout.closeDrawer(mNavigationView);
                        switchToReportBugFragment(false);
                        return true;
                    case R.id.navigation_item_donate:
                        mDrawerLayout.closeDrawer(mNavigationView);
                        return true;
                    case R.id.navigation_item_logout:
                        mDrawerLayout.closeDrawer(mNavigationView);
                        switchToLoginFragment(false, true);
                        return true;
                }

                return false;
            }
        });

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        mToggle = new ActionBarDrawerToggle
                (
                        this,
                        mDrawerLayout,
                        0, 0
                ) {
        };
        mDrawerLayout.setDrawerListener(mToggle);
        mToggle.syncState();

//        new AsyncTask<Void, Void, Void>() {
//
//            @Override
//            protected Void doInBackground(Void... params) {
//
//                String email = "possitron@gmail.com";
//                String location = "PL";
//                String language = "en";
//
//                JSONObject jsonObject = API.emailLogin("possitron@gmail.com", "f83a241de7b2cd737b323b60c4292277f45a964f", language, location);
//
//                Log.d("haha", "jsonObject: " + jsonObject.toString());
//
//                jsonObject = API.updateName("name", "surname", "nick");
//
//                Log.d("haha", "jsonObject: " + jsonObject.toString());
//
//
//                return null;
//            }
//
//
//        }.execute();

        if (savedInstanceState == null) {
            if (ProfileModel.get().email == null) {
                switchToLoginFragment(true, false);
            } else {
                // switchToProfileFragment(true);
                switchToTextsFragment(true);
                //switchToGroupsFragment(true);
                //switchToNotificationsFragment(true);
            }
        }
    }

    private void enableDrawer() {
        mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
        mToggle.setDrawerIndicatorEnabled(true);
    }

    private void disableDrawer() {
        mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
        mToggle.setDrawerIndicatorEnabled(false);
    }

    private void showFragment(Fragment fragment) {
        showFragment(fragment, false, false);
    }

    private void showFragment(Fragment fragment, boolean forceShow, boolean withPop) {
        if (!mActivityResumed && !forceShow)
            return;

        if (withPop) {
            getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction = transaction.addToBackStack(fragment.getClass().toString());
        transaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                .replace(R.id.container, fragment).commit();

        handleFragmentShown(fragment);
    }

    public void switchToProfileFragment(boolean forceShow) {
        ProfileFragment fragment = new ProfileFragment();
        showFragment(fragment, forceShow, true);
    }

    public void switchToGroupNewFragment(boolean forceShow) {
        GroupNewFragment fragment = new GroupNewFragment();
        showFragment(fragment, forceShow, false);
    }

    public void switchToGroupsFragment(boolean forceShow) {
        GroupsFragment fragment = new GroupsFragment();
        showFragment(fragment, forceShow, true);
    }

    public void switchToLoginFragment(boolean forceShow, boolean doLogout) {
        LoginFragment fragment = new LoginFragment();

        Bundle arguments = new Bundle();
        arguments.putBoolean(LoginFragment.DO_LOGOUT_PARAM, doLogout);

        fragment.setArguments(arguments);

        showFragment(fragment, forceShow, true);
    }

    public void switchToMessageToAdminFragment(boolean forceShow) {
        MessageToAdminFragment fragment = new MessageToAdminFragment();
        showFragment(fragment, forceShow, true);
    }

    public void switchToNotificationNewFragment(boolean forceShow) {
        NotificationNewFragment fragment = new NotificationNewFragment();
        showFragment(fragment, forceShow, false);
    }

    public void switchToNotificationsFragment(boolean forceShow) {
        NotificationsFragment fragment = new NotificationsFragment();
        showFragment(fragment, forceShow, true);
    }

    public void switchToReportBugFragment(boolean forceShow) {
        ReportBugFragment fragment = new ReportBugFragment();
        showFragment(fragment, forceShow, true);
    }

    public void switchToTextEditFragment(boolean forceShow, TextModel model) {
        TextEditFragment fragment = new TextEditFragment();

        Bundle arg = new Bundle();
        arg.putSerializable(TextReadingFragment.TEXT_MODEL_PARAM, model);
        fragment.setArguments(arg);

        showFragment(fragment, forceShow, false);
    }

    public void switchToTextReadingFragment(boolean forceShow, TextModel model) {
        TextReadingFragment fragment = new TextReadingFragment();

        Bundle arg = new Bundle();
        arg.putSerializable(TextReadingFragment.TEXT_MODEL_PARAM, model);
        fragment.setArguments(arg);

        showFragment(fragment, forceShow, false);
    }

    public void switchToTextsFragment(boolean forceShow) {
        TextsFragment fragment = new TextsFragment();
        showFragment(fragment, forceShow, true);
    }

    public void handleFragmentShown(Fragment f) {
        Log.d("haha", "handleFragmentShown");

        mCurrentFragment = f;

        if (f instanceof LoginFragment) {
            disableDrawer();
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            getSupportActionBar().setHomeButtonEnabled(false);
        } else {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            enableDrawer();
        }

        if (f instanceof TextReadingFragment || f instanceof TextEditFragment ||
                f instanceof GroupNewFragment || f instanceof NotificationNewFragment) {
            disableDrawer();
        }

        handleMenuChanges(f);


        getSupportActionBar().setTitle("Convocatis");

        if (f instanceof ProfileFragment) {
            getSupportActionBar().setTitle("Profile");
        }

        if (f instanceof TextsFragment) {
            getSupportActionBar().setTitle("Texts");
        }

        if (f instanceof TextEditFragment) {
            getSupportActionBar().setTitle("Text");
        }

        if (f instanceof TextReadingFragment) {
            getSupportActionBar().setTitle("Prayer");
        }

        if (f instanceof GroupsFragment) {
            getSupportActionBar().setTitle("Groups");
        }

        if (f instanceof NotificationsFragment) {
            getSupportActionBar().setTitle("Notifications");
        }

        if (f instanceof GroupNewFragment) {
            getSupportActionBar().setTitle("New group");
        }

        if (f instanceof NotificationNewFragment) {
            getSupportActionBar().setTitle("New notification");
        }

        if (f instanceof ReportBugFragment) {
            getSupportActionBar().setTitle("Report bug");
        }


        mMenuLayout.setVisibility(View.VISIBLE);

        if (f instanceof LoginFragment || f instanceof TextReadingFragment || f instanceof GroupNewFragment
                || f instanceof NotificationNewFragment || f instanceof TextEditFragment) {
            mMenuLayout.setVisibility(View.GONE);
        }

    }

    public void handleMenuChanges(Fragment f) {

        if (f == null) {
            return;
        }

        Log.d("haha", "handleMenuChanges");
        hideAllActionBarElements();

        if (mShowNavigationItem != null) {
            if (f instanceof TextReadingFragment) {
                mShowNavigationItem.setVisible(true);
            }

            if (f instanceof TextsFragment) {
                mShowHighlighted.setVisible(true);
                mSortBySchedule.setVisible(true);
                mSortAlpha.setVisible(true);
                showSearchView(null);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        mActivityResumed = true;

        final AdView mAdView = (AdView) findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                mAdView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                mAdView.setVisibility(View.GONE);
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        mActivityResumed = false;
    }

    @Override
    protected void onSaveInstanceState(Bundle state) {
        mActivityResumed = false;
        super.onSaveInstanceState(state);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.action_bar_menu, menu);

        mSearchView = (SearchView) menu.findItem(R.id.search).getActionView();

        ImageView searchClose = (ImageView) mSearchView.findViewById(android.support.v7.appcompat.R.id.search_close_btn);
        searchClose.setImageResource(R.drawable.ic_clear_white_24dp);

        mSearchMenuItem = menu.findItem(R.id.search);

        mSearchView.setOnQueryTextListener(
                new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        if (mOnSearchTermChangedListener != null) {
                            mOnSearchTermChangedListener.onSearchTermChanged(query);
                        }
                        mSearchView.clearFocus();
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        if (mOnSearchTermChangedListener != null) {
                            mOnSearchTermChangedListener.onSearchTermChanged(newText);
                        }
                        return false;
                    }
                }
        );

        MenuItemCompat.setOnActionExpandListener(mSearchMenuItem, new MenuItemCompat.OnActionExpandListener() {
            @Override
            public boolean onMenuItemActionExpand(MenuItem item) {

                if (mOnSearchTermChangedListener != null) {
                    mOnSearchTermChangedListener.onSearchStarted();
                }

                return true;
            }

            @Override
            public boolean onMenuItemActionCollapse(MenuItem item) {

                if (mOnSearchTermChangedListener != null) {
                    mOnSearchTermChangedListener.onSearchStopped();
                }

                if (mOnSearchTermChangedListener != null) {
                    mOnSearchTermChangedListener.onSearchTermChanged("");
                }

                return true;
            }
        });

        mShowNavigationItem = menu.findItem(R.id.show_navigation);
        mSortBySchedule = menu.findItem(R.id.sort_by_schedule);
        mSortAlpha = menu.findItem(R.id.sort_alpha);
        mShowHighlighted = menu.findItem(R.id.show_highlighted);

        handleMenuChanges(mCurrentFragment);

        return super.onCreateOptionsMenu(menu);
    }

    public void openSearchView(String searchTerm) {
        if (mSearchView.isIconified()) {
            mSearchMenuItem.expandActionView();
        }

        mSearchView.setQuery(searchTerm, false);
    }

    public void showSearchView(String searchTerm) {
        mSearchMenuItem.setVisible(true);
        mSearchView.setVisibility(View.VISIBLE);
        mSearchView.setEnabled(true);

        if (!TextUtils.isEmpty(searchTerm)) {
            openSearchView(searchTerm);
        }
    }

    public void hideSearchView() {
        mSearchMenuItem.setVisible(false);
        mSearchView.setVisibility(View.GONE);
        mSearchView.setEnabled(false);

        if (!mSearchView.isIconified()) {
            OnSearchTermChangedListener tmp = mOnSearchTermChangedListener;
            mOnSearchTermChangedListener = null;
            mSearchMenuItem.collapseActionView();
            mOnSearchTermChangedListener = tmp;
        }
    }

    private void hideAllActionBarElements() {
        if (mShowNavigationItem == null)
            return;

        mShowNavigationItem.setVisible(false);
        mSortBySchedule.setVisible(false);
        mSortAlpha.setVisible(false);
        mShowHighlighted.setVisible(false);

        hideSearchView();
    }

    public boolean showHighlighted() {

        if (mShowHighlighted != null) {
            return mShowHighlighted.isChecked();
        } else {
            return false;
        }
    }

    public boolean sortBySchedule() {
        if (mShowHighlighted != null) {
            return mSortBySchedule.isChecked();
        } else {
            return true;
        }
    }

    public boolean sortAlpha() {
        if (mSortAlpha != null) {
            return mSortAlpha.isChecked();
        } else {
            return false;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()) {
            case android.R.id.home:

                if (!goBack() && !mToggle.onOptionsItemSelected(item)) {
                    if (mOnOptionsItemSelectedFragmentListener != null) {
                        mOnOptionsItemSelectedFragmentListener.onOptionsItemSelectedFragment(item);
                    }
                    return super.onOptionsItemSelected(item);
                }

                return true;
            case R.id.sort_alpha:
                item.setChecked(true);
                mSortBySchedule.setChecked(false);

                if (mOnOptionsItemSelectedFragmentListener != null) {
                    mOnOptionsItemSelectedFragmentListener.onOptionsItemSelectedFragment(item);
                }
                return super.onOptionsItemSelected(item);
            case R.id.sort_by_schedule:
                item.setChecked(true);
                mSortAlpha.setChecked(false);

                if (mOnOptionsItemSelectedFragmentListener != null) {
                    mOnOptionsItemSelectedFragmentListener.onOptionsItemSelectedFragment(item);
                }
                return super.onOptionsItemSelected(item);
            case R.id.show_highlighted:
                item.setChecked(!item.isChecked());

            default:
                if (mOnOptionsItemSelectedFragmentListener != null) {
                    mOnOptionsItemSelectedFragmentListener.onOptionsItemSelectedFragment(item);
                }
                return super.onOptionsItemSelected(item);
        }


    }

    public boolean goBack() {
        if (!mActivityResumed)
            return false;

        if (getSupportFragmentManager().getBackStackEntryCount() > 1) {

            handleFragmentShown(getSupportFragmentManager().getFragments().get(getSupportFragmentManager().getBackStackEntryCount() - 2));

            getSupportFragmentManager().popBackStack();

            return true;
        }

        return false;
    }

    @Override
    public void onBackPressed() {

        if (!goBack()) {
//            if (!mSearchView.isIconified()) {
//                //mSearchView.setIconified(true);
//                mSearchMenuItem.collapseActionView();
//            } else {
//                finish();
//            }

            finish();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (mOnActivityResultListener != null) {
            mOnActivityResultListener.onActivityResultCalled(requestCode, resultCode, data);
        }
    }
}
