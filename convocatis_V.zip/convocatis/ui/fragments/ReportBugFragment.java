package net.convocatis.convocatis.ui.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import net.convocatis.convocatis.R;
import net.convocatis.convocatis.database.model.GroupModel;
import net.convocatis.convocatis.database.model.LanguageModel;
import net.convocatis.convocatis.database.model.ProfileModel;
import net.convocatis.convocatis.diskmanager.DiskTask;
import net.convocatis.convocatis.networking.API;
import net.convocatis.convocatis.networking.SynchronizationService;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by reactor on 1/25/16.
 */
public class ReportBugFragment extends BaseFragment {

    private EditText mMessageEdit;
    private Spinner mLanguagesSpinner;
    private Button mSendButton;

    private List<LanguageModel> mLanguages;
    private ArrayList<String> mLanguageNames;

    private LayoutInflater mLayoutInflater;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mLayoutInflater = inflater;

        View v = inflater.inflate(R.layout.report_bug_fragment, container, false);

        mMessageEdit = (EditText) v.findViewById(R.id.message_edit);
        mLanguagesSpinner = (Spinner) v.findViewById(R.id.languages_spinner);

        mSendButton = (Button) v.findViewById(R.id.send_button);

        new DiskTask() {
            List<LanguageModel> languages;

            @Override
            public void getData() {
                languages = LanguageModel.getAllLanguages();

                ProfileModel profile = ProfileModel.get();

                ArrayList<Long> idss = new ArrayList<Long>();

                if (!TextUtils.isEmpty(profile.myLanguagesIds)) {
                    String[] ids = profile.myLanguagesIds.split(",");

                    for (int i = 0; i < ids.length; i++) {
                        String stringId = ids[i];

                        long langId = -1;
                        try {
                            langId = Long.parseLong(stringId);
                        } catch (NumberFormatException e) {
                        }

                        if (langId > -1) {
                            idss.add(langId);
                        }
                    }
                }

                if (profile.uiLangId != null && !idss.contains(profile.uiLangId)) {
                    idss.add(profile.uiLangId);
                }

                List<LanguageModel> l = new ArrayList<LanguageModel>();

                for (LanguageModel model : languages) {
                    if (idss.contains(model.backendId)) {
                        l.add(model);
                    }
                }

                languages = l;

            }

            @Override
            public void onDataReceived() {
                mLanguages = languages;
                onDataLoaded();
            }
        }.execute(this);

        return v;
    }

    public void onDataLoaded() {

        mLanguageNames = new ArrayList<String>();

        for (int i = 0; i < mLanguages.size(); i++) {
            mLanguageNames.add(mLanguages.get(i).name);
        }

        final ArrayAdapter<String> languagesAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_list_item_1,
                mLanguageNames);
        mLanguagesSpinner.setAdapter(languagesAdapter);

        int selectedLanguage = 0;

        mLanguagesSpinner.setSelection(selectedLanguage);

        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String message = mMessageEdit.getText().toString();
                final long language = mLanguages.get(mLanguagesSpinner.getSelectedItemPosition()).backendId;

                new DiskTask() {

                    JSONObject obj;

                    @Override
                    public void getData() {
                        obj = API.sendBug(message, language);


                    }

                    @Override
                    public void onDataReceived() {


                        boolean success = true;

                        try {
                            if (obj == null || !obj.getBoolean("status")) {
                                success = false;
                            }
                        } catch (JSONException e) {
                            success = false;
                        }

                        if (!success) {
                            Toast.makeText(mMainActivity, "ERROR. Message not sent.", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(mMainActivity, "Message sent with SUCCESS.", Toast.LENGTH_SHORT).show();
                        }

                    }
                }.execute(ReportBugFragment.this);

            }
        });
    }
}
