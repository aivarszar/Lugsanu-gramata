package net.convocatis.convocatis.ui.fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import net.convocatis.convocatis.R;
import net.convocatis.convocatis.database.model.LanguageModel;
import net.convocatis.convocatis.database.model.TextModel;
import net.convocatis.convocatis.diskmanager.DiskTask;
import net.convocatis.convocatis.networking.API;
import net.convocatis.convocatis.networking.SynchronizationService;
import net.convocatis.convocatis.receivers.AlarmReceiver;
import net.convocatis.convocatis.ui.MainActivity;

import org.w3c.dom.Text;

import java.util.Comparator;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;


/**
 * Created by reactor on 1/25/16.
 */
public class TextsFragment extends BaseFragment implements MainActivity.OnSearchTermChangedListener, MainActivity.OnOptionsItemSelectedFragmentListener {

    @Override
    public void onSearchTermChanged(String searchTerm) {
        Log.d("haha", "onSearchTermChanged: " + searchTerm);
        if (mSearchPending) {
            mSearchString = searchTerm;

            filterData();
        }
    }

    @Override
    public void onSearchStarted() {
        Log.d("haha", "onSearchStarted");
        mSearchPending = true;
    }

    @Override
    public void onSearchStopped() {
        Log.d("haha", "onSearchStopped");
        mSearchPending = false;

        mSearchString = "";
        filterData();
    }

    @Override
    public void onOptionsItemSelectedFragment(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.sort_alpha:
            case R.id.sort_by_schedule:
            case R.id.show_highlighted:
                filterData();
        }
    }

    public class MyAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return mTextsFiltered.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final TextModel model = mTextsFiltered.get(position);

            View view = mLayoutInflater.inflate(R.layout.texts_item, parent, false);

            TextView titleText = (TextView) view.findViewById(R.id.title_text);
            View detailsLayout = view.findViewById(R.id.details_layout);
            TextView prevText = (TextView) view.findViewById(R.id.preview_text);
            TextView privateText = (TextView) view.findViewById(R.id.private_text);
            View ratingLayout = view.findViewById(R.id.rating_layout);
            View removeButton = view.findViewById(R.id.remove_button);

            if (model.expanded) {
                detailsLayout.setVisibility(View.VISIBLE);
            } else {
                detailsLayout.setVisibility(View.GONE);
            }

            titleText.setText(model.title);
            prevText.setText(model.text);

            TextView ratingText = (TextView) view.findViewById(R.id.rating_text);
            ratingText.setText("" + model.rating);

            View likeButton = view.findViewById(R.id.like_button);
            View dislikeButton = view.findViewById(R.id.dislike_button);
            View readButton = view.findViewById(R.id.read_button);
            View editButton = view.findViewById(R.id.edit_button);
            View markDefaultButton = view.findViewById(R.id.mark_default_button);
            View highlightButton = view.findViewById(R.id.highlight_button);
            View shareButton = view.findViewById(R.id.share_button);
            ImageView likeImage = (ImageView) view.findViewById(R.id.like_image);
            ImageView dislikeImage = (ImageView) view.findViewById(R.id.dislike_image);
            ImageView defaultImage = (ImageView) view.findViewById(R.id.default_image);
            ImageView highlightImage = (ImageView) view.findViewById(R.id.highlight_image);

            if (model.like != null) {
                if (model.like) {
                    likeImage.setColorFilter(0xFF2570c3);
                } else {
                    dislikeImage.setColorFilter(0xFF2570c3);
                }
            }

            if (model.highlighted) {
                view.setBackgroundColor(0xFFFFFF90);
                highlightImage.setColorFilter(0xFFFF0000);
            }

            if (model.isDefault != null && model.isDefault) {
                defaultImage.setColorFilter(0xFFFF0000);
            }

            if (model.backendId != null) {
                privateText.setVisibility(View.GONE);
                shareButton.setVisibility(View.GONE);
            } else {
                likeButton.setVisibility(View.GONE);
                dislikeButton.setVisibility(View.GONE);
                ratingLayout.setVisibility(View.GONE);
            }

            if (model.isShared != null && model.isShared) {
                shareButton.setVisibility(View.GONE);
            }

            likeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    new DiskTask() {
                        @Override
                        public void getData() {
                            model.like = true;
                            model.likeDirty = true;
                            model.persist();
                        }

                        @Override
                        public void onDataReceived() {
                            notifyDataSetChanged();
                            SynchronizationService.startSync(true);
                        }
                    }.execute(TextsFragment.this);

                }
            });

            dislikeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    new DiskTask() {
                        @Override
                        public void getData() {
                            model.like = false;
                            model.likeDirty = true;
                            model.persist();
                        }

                        @Override
                        public void onDataReceived() {
                            notifyDataSetChanged();
                            SynchronizationService.startSync(true);
                        }
                    }.execute(TextsFragment.this);

                }
            });

            readButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mMainActivity.switchToTextReadingFragment(false, model);
                }
            });

            editButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mMainActivity.switchToTextEditFragment(false, model);
                }
            });

            markDefaultButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    new DiskTask() {
                        @Override
                        public void getData() {

                            for (int i = 0; i < mTexts.size(); i++) {
                                if (mTexts.get(i).isDefault != null && mTexts.get(i).isDefault) {
                                    mTexts.get(i).isDefault = false;
                                    mTexts.get(i).persist();
                                    break;
                                }
                            }

                            model.isDefault = true;
                            model.persist();
                        }

                        @Override
                        public void onDataReceived() {
                            notifyDataSetChanged();
                        }
                    }.execute(TextsFragment.this);
                }
            });

            highlightButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    new DiskTask() {
                        @Override
                        public void getData() {

                            if (!model.highlighted) {
                                model.highlighted = true;

                                long time = model.getNextPrayerTime();

                                if (time != -1) {
                                    AlarmReceiver.startAlarm(mMainActivity, time, (int) (model.id * 1), "Prayer", model.title);
                                }

                            } else {
                                model.highlighted = false;
                                AlarmReceiver.cancelAlarm(mMainActivity, (int) (model.id * 1));
                            }
                            model.persist();
                        }

                        @Override
                        public void onDataReceived() {
                            notifyDataSetChanged();

                            if (!model.highlighted && mShowHighlighted) {
                                filterData();
                            }
                        }
                    }.execute(TextsFragment.this);
                }
            });

            shareButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new DiskTask() {
                        @Override
                        public void getData() {
                            model.isShared = true;
                            model.isSharedDirty = true;
                            model.persist();
                        }

                        @Override
                        public void onDataReceived() {
                            notifyDataSetChanged();
                            SynchronizationService.startSync(true);
                        }
                    }.execute(TextsFragment.this);
                }
            });

            removeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    AlertDialog.Builder b = new AlertDialog.Builder(mMainActivity);

                    b.setMessage("Delete text?");
                    b.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            for (int i = 0; i < mTexts.size(); i++) {
                                if (mTexts.get(i).id == model.id) {
                                    mTexts.remove(i);
                                    break;
                                }
                            }

                            new DiskTask() {
                                @Override
                                public void getData() {
                                    model.delete();
                                }

                                @Override
                                public void onDataReceived() {
                                    filterData();
                                }
                            }.execute(TextsFragment.this);

                        }
                    });

                    b.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    b.show();

                }
            });

            return view;
        }
    }

    private List<TextModel> mTexts;
    private List<TextModel> mTextsFiltered = new ArrayList<TextModel>();
    private ListView mListView;
    private MyAdapter mAdapter;
    private LayoutInflater mLayoutInflater;
    private FloatingActionButton mActionButton;
    private boolean mSearchPending;
    private String mSearchString;
    private boolean mShowHighlighted, mSortBySchedule, mSortAlphabetically;

    private void filterData() {

        mShowHighlighted = mMainActivity.showHighlighted();
        mSortBySchedule = mMainActivity.sortBySchedule();
        mSortAlphabetically = mMainActivity.sortAlpha();

        mTextsFiltered.clear();

        for (int i = 0; i < mTexts.size(); i++) {
            TextModel model = mTexts.get(i);

            if (TextUtils.isEmpty(mSearchString) ||
                    (model.title != null && model.title.toLowerCase().contains(mSearchString.toLowerCase())) ||
                    (model.text != null && model.text.toLowerCase().contains(mSearchString.toLowerCase())) ||
                    (model.code != null && model.code.toLowerCase().contains(mSearchString.toLowerCase())) ||
                    (model.type != null && (""+model.type).contains(mSearchString.toLowerCase()))


                    ) {

                if (!mShowHighlighted || model.highlighted) {
                    mTextsFiltered.add(model);
                }
            }
        }

        if (mSortAlphabetically) {
            Collections.sort(mTextsFiltered, new Comparator<TextModel>() {
                @Override
                public int compare(TextModel lhs, TextModel rhs) {

                    return lhs.title.toLowerCase().compareTo(rhs.title.toLowerCase());
                }
            });
        } else if (mSortBySchedule) {
            Collections.sort(mTextsFiltered, new Comparator<TextModel>() {
                @Override
                public int compare(TextModel lhs, TextModel rhs) {

                    if (lhs.getNextPrayerTime() == -1) {
                        return 1;
                    }

                    if (rhs.getNextPrayerTime() == -1) {
                        return -1;
                    }

                    return (int) (lhs.getNextPrayerTime() / 1000 - rhs.getNextPrayerTime() / 1000);
                }
            });
        }

        mAdapter.notifyDataSetChanged();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mLayoutInflater = inflater;
        View v = inflater.inflate(R.layout.texts_fragment, container, false);

        if (mSearchPending) {
            mMainActivity.openSearchView(mSearchString);
        }

        mActionButton = (FloatingActionButton) v.findViewById(R.id.action_button);

        mActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMainActivity.switchToTextEditFragment(false, null);
            }
        });

        mListView = (ListView) v.findViewById(R.id.list_view);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {

                if (mTextsFiltered.get(position).expanded) {
                    mTextsFiltered.get(position).expanded = false;
                } else {
                    for (TextModel model : mTextsFiltered) {
                        model.expanded = false;
                    }
                    mTextsFiltered.get(position).expanded = true;
                }

                mAdapter.notifyDataSetChanged();
            }
        });

        mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                mMainActivity.switchToTextReadingFragment(false, mTextsFiltered.get(position));

                return true;
            }
        });

        mAdapter = new MyAdapter();

        new DiskTask() {

            @Override
            public void getData() {
                mTexts = TextModel.getAllTexts();
            }

            @Override
            public void onDataReceived() {
                mListView.setAdapter(mAdapter);
                filterData();
            }

        }.execute(this);

        mMainActivity.setOnSearchTermChangedListener(this);
        mMainActivity.setOnOptionsItemSelectedListener(this);

        return v;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mMainActivity.setOnSearchTermChangedListener(null);
        mMainActivity.setOnOptionsItemSelectedListener(null);
    }
}
