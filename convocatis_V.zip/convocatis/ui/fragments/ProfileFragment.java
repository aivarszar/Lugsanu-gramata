package net.convocatis.convocatis.ui.fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import net.convocatis.convocatis.R;
import net.convocatis.convocatis.database.model.DenominationModel;
import net.convocatis.convocatis.database.model.GroupModel;
import net.convocatis.convocatis.database.model.LanguageModel;
import net.convocatis.convocatis.database.model.ProfileModel;
import net.convocatis.convocatis.diskmanager.DiskTask;
import net.convocatis.convocatis.networking.API;
import net.convocatis.convocatis.networking.SynchronizationService;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by reactor on 1/25/16.
 */
public class ProfileFragment extends BaseFragment implements SynchronizationService.OnSynchronizationFinishedListener {

    private List<LanguageModel> mLanguages;
    private List<DenominationModel> mDenominations;
    private ArrayList<String> mLanguageNames, mDenominationNames;

    private List<LanguageModel> mMyLanguagesAr;
    private ArrayList<String> mMyLanguageNames;

    private Spinner mLanguagesSpinner;
    private Spinner mDenominationsSpinner;
    private View mMyLanguagesLayout;
    private TextView mMyLanguagesText;

    private ProfileModel mProfileModel;
    private ArrayList<Long> mMyLanguages;
    private EditText mNameEdit, mSurnameEdit, mNicknameEdit;

    private Button mSynchronizeButton, mDeleteButton;

    private CheckBox mOtherDenominationsCheckbox, mNotificationsCheckbox;

    private int mSyncState;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.profile_fragment, container, false);
        mMyLanguagesLayout = v.findViewById(R.id.my_languages_layout);
        mMyLanguagesText = (TextView) v.findViewById(R.id.my_languages_text);
        mLanguagesSpinner = (Spinner) v.findViewById(R.id.languages_spinner);
        mDenominationsSpinner = (Spinner) v.findViewById(R.id.denominations_spinner);
        mNameEdit = (EditText) v.findViewById(R.id.name_edit);
        mSurnameEdit = (EditText) v.findViewById(R.id.surname_edit);
        mNicknameEdit = (EditText) v.findViewById(R.id.nickname_edit);
        mOtherDenominationsCheckbox = (CheckBox) v.findViewById(R.id.other_denominations_checkbox);
        mNotificationsCheckbox = (CheckBox) v.findViewById(R.id.notifications_checkbox);
        mSynchronizeButton = (Button) v.findViewById(R.id.synchronize_button);
        mDeleteButton = (Button) v.findViewById(R.id.delete_button);

        new DiskTask() {
            List<LanguageModel> languages;
            List<LanguageModel> myLanguages;
            List<DenominationModel> denominations;
            ProfileModel profileModel;

            @Override
            public void getData() {
                languages = LanguageModel.getAllLanguagesWithUIStrings();
                myLanguages = LanguageModel.getAllLanguages();
                denominations = DenominationModel.getAllDenominations();
                profileModel = ProfileModel.get();
            }

            @Override
            public void onDataReceived() {
                mLanguages = languages;
                mMyLanguagesAr = myLanguages;
                mDenominations = denominations;
                mProfileModel = profileModel;
                onDataLoaded();
            }
        }.execute(this);

        SynchronizationService.setOnSynchronizationFinishedListener(this);

        return v;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        SynchronizationService.setOnSynchronizationFinishedListener(null);
    }

    public void onDataLoaded() {
        String myLanguageIds = mProfileModel.myLanguagesIds;
        mMyLanguages = new ArrayList<Long>();

        if (!TextUtils.isEmpty(myLanguageIds)) {
            String[] ids = myLanguageIds.split(",");

            for (int i = 0; i < ids.length; i++) {
                String stringId = ids[i];

                long langId = -1;
                try {
                    langId = Long.parseLong(stringId);
                } catch (NumberFormatException e) {
                }

                if (langId > -1) {
                    mMyLanguages.add(langId);
                }
            }
        }

        mLanguageNames = new ArrayList<String>();
        mMyLanguageNames = new ArrayList<String>();
        mDenominationNames = new ArrayList<String>();

        for (int i = 0; i < mLanguages.size(); i++) {
            mLanguageNames.add(mLanguages.get(i).name);
        }

        for (int i = 0; i < mMyLanguagesAr.size(); i++) {
            mMyLanguageNames.add(mMyLanguagesAr.get(i).name);
        }

        for (int i = 0; i < mDenominations.size(); i++) {
            mDenominationNames.add(mDenominations.get(i).name);
        }

        final ArrayAdapter<String> languagesAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_list_item_1,
                mLanguageNames);
        mLanguagesSpinner.setAdapter(languagesAdapter);

        final ArrayAdapter<String> denominationsAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_list_item_1,
                mDenominationNames);
        mDenominationsSpinner.setAdapter(denominationsAdapter);

        int selectedLanguage = 0;

        for (int i = 0; i < mLanguages.size(); i++) {
            if (mLanguages.get(i).backendId == mProfileModel.uiLangId) {
                selectedLanguage = i;
                break;
            }
        }

        mLanguagesSpinner.setSelection(selectedLanguage);


        int selectedDenomination = 0;

        for (int i = 0; i < mDenominations.size(); i++) {
            if (mDenominations.get(i).backendId == mProfileModel.denominationId) {
                selectedDenomination = i;
                break;
            }
        }

        mDenominationsSpinner.setSelection(selectedDenomination);


        mLanguagesSpinner.post(new Runnable() {
            @Override
            public void run() {

                mLanguagesSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        mProfileModel.uiLangId = mLanguages.get(position).backendId;
                        mProfileModel.uiLangIdDirty = true;
                        new DiskTask() {

                            @Override
                            public void getData() {
                                mProfileModel.save();
                            }

                            @Override
                            public void onDataReceived() {

                            }
                        }.execute();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
            }
        });

        mDenominationsSpinner.post(new Runnable() {
            @Override
            public void run() {

                mDenominationsSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        mProfileModel.denominationId = mDenominations.get(position).backendId;
                        mProfileModel.denominationIdDirty = true;
                        new DiskTask() {

                            @Override
                            public void getData() {

                                mProfileModel.save();
                            }

                            @Override
                            public void onDataReceived() {

                            }
                        }.execute();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
            }
        });

        Log.d("haha", "profile fragment other denominations enabled: " + mProfileModel.otherDenominationsEnabled);

        mOtherDenominationsCheckbox.setChecked(mProfileModel.otherDenominationsEnabled);
        mNotificationsCheckbox.setChecked(mProfileModel.notificationsEnabled);

        onMyLanguagesUpdated(false);

        mNameEdit.setText(mProfileModel.name);
        mSurnameEdit.setText(mProfileModel.surname);
        mNicknameEdit.setText(mProfileModel.nick);

        mMyLanguagesLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String[] names = new String[mMyLanguagesAr.size()];
                boolean[] values = new boolean[mMyLanguagesAr.size()];

                for (int i = 0; i < mMyLanguagesAr.size(); i++) {
                    names[i] = mMyLanguagesAr.get(i).name;
                    values[i] = false;
                    if (mMyLanguages.contains(mMyLanguagesAr.get(i).backendId)) {
                        values[i] = true;
                    }
                }

                AlertDialog d = new AlertDialog.Builder(mMainActivity)
                        .setTitle("My languages:")
                        .setMultiChoiceItems(names, values, new DialogInterface.OnMultiChoiceClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which, boolean isChecked) {

                            }
                        }).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                AlertDialog alertDialog = (AlertDialog) dialog;

                                mMyLanguages.clear();

                                for (int i = 0; i < alertDialog.getListView().getCheckedItemPositions().size(); i++) {
                                    int key = alertDialog.getListView().getCheckedItemPositions().keyAt(i);
                                    boolean value = alertDialog.getListView().getCheckedItemPositions().valueAt(i);
                                    if (value) {
                                        mMyLanguages.add(mMyLanguagesAr.get(key).backendId);
                                    }
                                }

                                onMyLanguagesUpdated(true);
                            }
                        })
                        .create();

                d.show();
            }
        });

        mOtherDenominationsCheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                mProfileModel.otherDenominationsEnabled = isChecked;
                mProfileModel.otherDenominationsEnabledDirty = true;

                new DiskTask() {

                    @Override
                    public void getData() {
                        mProfileModel.save();
                    }

                    @Override
                    public void onDataReceived() {

                    }
                }.execute();

            }
        });

        mNotificationsCheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                mProfileModel.notificationsEnabled = isChecked;
                mProfileModel.notificationsEnabledDirty = true;
                new DiskTask() {

                    @Override
                    public void getData() {
                        mProfileModel.save();
                    }

                    @Override
                    public void onDataReceived() {

                    }
                }.execute();
            }
        });


        mNameEdit.post(new Runnable() {
            @Override
            public void run() {
                mNameEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        if (!hasFocus && !TextUtils.equals(mProfileModel.name, mNameEdit.getText().toString())) {
                            mProfileModel.name = mNameEdit.getText().toString();
                            mProfileModel.nameSurnameNickDirty = true;
                            new DiskTask() {

                                @Override
                                public void getData() {
                                    mProfileModel.save();
                                }

                                @Override
                                public void onDataReceived() {

                                }
                            }.execute();
                        }
                    }
                });
            }
        });

        mSurnameEdit.post(new Runnable() {
            @Override
            public void run() {
                mSurnameEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        if (!hasFocus && !TextUtils.equals(mProfileModel.surname, mSurnameEdit.getText().toString())) {
                            mProfileModel.surname = mSurnameEdit.getText().toString();
                            mProfileModel.nameSurnameNickDirty = true;
                            new DiskTask() {

                                @Override
                                public void getData() {
                                    mProfileModel.save();
                                }

                                @Override
                                public void onDataReceived() {

                                }
                            }.execute();
                        }
                    }
                });
            }
        });

        mNicknameEdit.post(new Runnable() {
            @Override
            public void run() {
                mNicknameEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        if (!hasFocus && !TextUtils.equals(mProfileModel.nick, mNicknameEdit.getText().toString())) {
                            mProfileModel.nick = mNicknameEdit.getText().toString();
                            mProfileModel.nameSurnameNickDirty = true;
                            new DiskTask() {

                                @Override
                                public void getData() {
                                    mProfileModel.save();
                                }

                                @Override
                                public void onDataReceived() {

                                }
                            }.execute();
                        }
                    }
                });
            }
        });

        mSynchronizeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mSyncState != 0) {
                    return;
                }

                mSyncState = 1;
                showProgressDialog();

                SynchronizationService.startSync(true);
            }
        });

        mDeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog dialog = new AlertDialog.Builder(mMainActivity).setTitle("Delete account?").setMessage("Are you sure you want to delete your account?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        new DiskTask() {

                            JSONObject jo;

                            @Override
                            public void getData() {
                                jo = API.deleteAccount();
                            }

                            @Override
                            public void onDataReceived() {

                                try {
                                    if (jo != null && jo.has("status") && jo.getBoolean("status")) {
                                        mMainActivity.switchToLoginFragment(false, true);
                                        return;
                                    }
                                } catch (JSONException e) {
                                }

                                Toast.makeText(mMainActivity, "Network error", Toast.LENGTH_SHORT).show();
                            }
                        }.execute(ProfileFragment.this);


                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                }).create();
                dialog.show();

            }
        });
    }

    public void onMyLanguagesUpdated(boolean makeDirty) {
        String t = "";

        for (int i = 0; i < mMyLanguagesAr.size(); i++) {
            if (mMyLanguages.contains(mMyLanguagesAr.get(i).backendId)) {
                if (t.length() > 0) {
                    t += ", ";
                }
                t += mMyLanguagesAr.get(i).name;
            }
        }

        if (t.length() == 0) {
            mMyLanguagesText.setText("No languages selected");
        } else {
            mMyLanguagesText.setText(t);
        }

        if (makeDirty) {
            String myLanguagesString = "";
            for (int i = 0; i < mMyLanguages.size(); i++) {
                if (myLanguagesString.length() > 0) {
                    myLanguagesString += ",";
                }
                myLanguagesString += mMyLanguages.get(i);
            }

            if (mProfileModel.myServerLanguagesIds == null) {
                mProfileModel.myServerLanguagesIds = mProfileModel.myLanguagesIds;
            }

            mProfileModel.myLanguagesIds = myLanguagesString;
            new DiskTask() {

                @Override
                public void getData() {
                    mProfileModel.save();
                }

                @Override
                public void onDataReceived() {

                }
            }.execute();
        }
    }

    @Override
    public void onSynchronizationStarted(boolean fullSync) {
        Log.d("haha", "sync started");

        if (mSyncState == 1) {
            mSyncState = 2;
        }
    }

    @Override
    public void onSynchronizationFinished(boolean fullSync, boolean success) {
        Log.d("haha", "sync finished " + success);

        if (mSyncState == 2) {
            dismissProgressDialog();
            mSyncState = 0;

            if (success) {
                Toast.makeText(mMainActivity, "Synchronization successful", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(mMainActivity, "Synchronization failed", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
