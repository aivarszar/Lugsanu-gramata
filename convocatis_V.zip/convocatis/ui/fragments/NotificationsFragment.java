package net.convocatis.convocatis.ui.fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.games.Notifications;

import net.convocatis.convocatis.R;
import net.convocatis.convocatis.database.model.GroupModel;
import net.convocatis.convocatis.database.model.NotificationModel;
import net.convocatis.convocatis.database.model.TextModel;
import net.convocatis.convocatis.diskmanager.DiskTask;
import net.convocatis.convocatis.networking.SynchronizationService;

import java.security.acl.Group;
import java.util.List;

/**
 * Created by reactor on 1/25/16.
 */
public class NotificationsFragment extends BaseFragment {

    public class MyAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return mNotifications.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final NotificationModel model = mNotifications.get(position);

            View view = mLayoutInflater.inflate(R.layout.notifications_item, parent, false);

            TextView titleText = (TextView) view.findViewById(R.id.title_text);
            View detailsLayout = view.findViewById(R.id.details_layout);
            TextView nicknameText = (TextView) view.findViewById(R.id.nickname_text);
            TextView dateText = (TextView) view.findViewById(R.id.date_text);
            TextView ratingText = (TextView) view.findViewById(R.id.rating_text);
            ImageView likeImage = (ImageView) view.findViewById(R.id.like_image);
            ImageView dislikeImage = (ImageView) view.findViewById(R.id.dislike_image);
            ImageView highlightImage = (ImageView) view.findViewById(R.id.highlight_image);
            CheckBox hideCheckbox = (CheckBox) view.findViewById(R.id.hide_checkbox);
            View removeButton = view.findViewById(R.id.remove_button);

            removeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    AlertDialog.Builder b = new AlertDialog.Builder(mMainActivity);

                    b.setMessage("Delete notification?");
                    b.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            for (int i = 0; i < mNotifications.size(); i++) {
                                if (mNotifications.get(i).id == model.id) {
                                    mNotifications.remove(i);
                                    break;
                                }
                            }

                            new DiskTask() {
                                @Override
                                public void getData() {
                                    model.deleted = true;
                                    model.persist();
                                }

                                @Override
                                public void onDataReceived() {
                                    notifyDataSetChanged();
                                }
                            }.execute(NotificationsFragment.this);

                        }
                    });

                    b.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    b.show();

                }
            });

            hideCheckbox.setChecked(!model.hidden);

            hideCheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked) {

                    new DiskTask() {

                        @Override
                        public void getData() {
                            model.hidden = !isChecked;
                            model.persist();
                        }

                        @Override
                        public void onDataReceived() {

                        }
                    }.execute();


                }
            });

            if (model.expanded) {
                detailsLayout.setVisibility(View.VISIBLE);
            } else {
                detailsLayout.setVisibility(View.GONE);
            }

            String message = model.message;

            if (model.counter != null) {
                message += " (" + model.counter + ")";
            }

            titleText.setText(message);

            nicknameText.setText(model.userNick);
            dateText.setText(model.date);
            ratingText.setText("" + model.rating);


            View likeButton = view.findViewById(R.id.like_button);
            View dislikeButton = view.findViewById(R.id.dislike_button);
            View highlightButton = view.findViewById(R.id.highlight_button);

            if (model.highlighted != null && model.highlighted) {
                view.setBackgroundColor(0xFFFFFF90);
                highlightImage.setColorFilter(0xFFFF0000);
            }

            if (model.like != null) {
                if (model.like) {
                    likeImage.setColorFilter(0xFF2570c3);
                } else {
                    dislikeImage.setColorFilter(0xFF2570c3);
                }
            }

            if (model.backendId != null) {
            } else {
                likeButton.setVisibility(View.GONE);
                dislikeButton.setVisibility(View.GONE);
            }

            likeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    new DiskTask() {
                        @Override
                        public void getData() {
                            model.like = true;
                            model.likeDirty = true;
                            model.persist();
                        }

                        @Override
                        public void onDataReceived() {
                            notifyDataSetChanged();
                            SynchronizationService.startSync(true);
                        }
                    }.execute(NotificationsFragment.this);

                }
            });

            dislikeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    new DiskTask() {
                        @Override
                        public void getData() {
                            model.like = false;
                            model.likeDirty = true;
                            model.persist();
                        }

                        @Override
                        public void onDataReceived() {
                            notifyDataSetChanged();
                            SynchronizationService.startSync(true);
                        }
                    }.execute(NotificationsFragment.this);

                }
            });

            highlightButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    new DiskTask() {
                        @Override
                        public void getData() {

                            if (model.highlighted == null || !model.highlighted) {
                                model.highlighted = true;
                            } else {
                                model.highlighted = false;
                            }
                            model.persist();
                        }

                        @Override
                        public void onDataReceived() {
                            notifyDataSetChanged();
                        }
                    }.execute(NotificationsFragment.this);
                }
            });

            return view;
        }
    }

    private List<NotificationModel> mNotifications;
    private List<GroupModel> mGroupModels;
    private ListView mListView;
    private MyAdapter mAdapter;
    private LayoutInflater mLayoutInflater;
    private FloatingActionButton mActionButton;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mLayoutInflater = inflater;
        View v = inflater.inflate(R.layout.notifications_fragment, container, false);

        mActionButton = (FloatingActionButton) v.findViewById(R.id.action_button);

        mActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean joined = false;

                for (GroupModel model : mGroupModels) {
                    if (!TextUtils.isEmpty(model.joined) || model.tryingToJoin) {
                        joined = true;
                        break;
                    }
                }

                if (joined) {
                    mMainActivity.switchToNotificationNewFragment(false);
                } else {
                    Toast.makeText(mMainActivity, "You have not joined any groups.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        mListView = (ListView) v.findViewById(R.id.list_view);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {

                if (mNotifications.get(position).expanded) {
                    mNotifications.get(position).expanded = false;
                } else {
                    for (NotificationModel model : mNotifications) {
                        model.expanded = false;
                    }
                    mNotifications.get(position).expanded = true;
                }


                mAdapter.notifyDataSetChanged();
            }
        });

        mAdapter = new MyAdapter();

        new DiskTask() {
            @Override
            public void getData() {
                mNotifications = NotificationModel.getAllNotifications();
                mGroupModels = GroupModel.getAllGroups();
            }

            @Override
            public void onDataReceived() {
                mListView.setAdapter(mAdapter);
            }
        }.execute(this);

        return v;
    }
}
