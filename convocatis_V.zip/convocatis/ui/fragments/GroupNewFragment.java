package net.convocatis.convocatis.ui.fragments;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import net.convocatis.convocatis.R;
import net.convocatis.convocatis.database.model.DenominationModel;
import net.convocatis.convocatis.database.model.GroupModel;
import net.convocatis.convocatis.database.model.LanguageModel;
import net.convocatis.convocatis.database.model.TextModel;
import net.convocatis.convocatis.diskmanager.DiskTask;
import net.convocatis.convocatis.networking.SynchronizationService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by reactor on 1/25/16.
 */
public class GroupNewFragment extends BaseFragment {
    public GroupModel mGroupModel;

    private EditText mTitleEdit, mDescriptionEdit;
    private Spinner mLanguagesSpinner;
    private Button mCreateButton;
    private CheckBox mPrivateCheckbox, mMyDenominationCheckbox;

    private List<LanguageModel> mLanguages;
    private ArrayList<String> mLanguageNames;

    private LayoutInflater mLayoutInflater;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mGroupModel = new GroupModel();
        mGroupModel.name = "";
        mGroupModel.description = "";
        mGroupModel.myDenomination = false;
        mGroupModel.isPrivate = false;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mLayoutInflater = inflater;

        View v = inflater.inflate(R.layout.group_new_fragment, container, false);

        mTitleEdit = (EditText) v.findViewById(R.id.title_edit);
        mDescriptionEdit = (EditText) v.findViewById(R.id.description_edit);
        mLanguagesSpinner = (Spinner) v.findViewById(R.id.languages_spinner);

        mPrivateCheckbox = (CheckBox) v.findViewById(R.id.private_checkbox);
        mMyDenominationCheckbox = (CheckBox) v.findViewById(R.id.mydenomination_checkbox);

        mCreateButton = (Button) v.findViewById(R.id.create_button);

        new DiskTask() {
            List<LanguageModel> languages;

            @Override
            public void getData() {
                languages = LanguageModel.getAllLanguages();
            }

            @Override
            public void onDataReceived() {
                mLanguages = languages;
                onDataLoaded();
            }
        }.execute(this);

        return v;
    }

    public void onDataLoaded() {

        mLanguageNames = new ArrayList<String>();

        for (int i = 0; i < mLanguages.size(); i++) {
            mLanguageNames.add(mLanguages.get(i).name);
        }

        final ArrayAdapter<String> languagesAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_list_item_1,
                mLanguageNames);
        mLanguagesSpinner.setAdapter(languagesAdapter);

        if (mGroupModel.langId == null) {
            mGroupModel.langId = mLanguages.get(0).backendId;
        }

        int selectedLanguage = 0;

        for (int i = 0; i < mLanguages.size(); i++) {
            if (mLanguages.get(i).backendId == mGroupModel.langId) {
                selectedLanguage = i;
                break;
            }
        }

        mLanguagesSpinner.setSelection(selectedLanguage);


        mTitleEdit.setText(mGroupModel.name);
        mDescriptionEdit.setText(mGroupModel.description);

        mCreateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mGroupModel.backendId = (long) -1;
                mGroupModel.name = mTitleEdit.getText().toString();
                mGroupModel.description = mDescriptionEdit.getText().toString();
                mGroupModel.langId = mLanguages.get(mLanguagesSpinner.getSelectedItemPosition()).backendId;
                mGroupModel.isPrivate = mPrivateCheckbox.isChecked();
                mGroupModel.myDenomination = mMyDenominationCheckbox.isChecked();

                new DiskTask() {
                    @Override
                    public void getData() {
                        mGroupModel.persist();
                    }

                    @Override
                    public void onDataReceived() {
                        SynchronizationService.startSync(true);
                        mMainActivity.goBack();
                    }
                }.execute(GroupNewFragment.this);

            }
        });
    }
}
