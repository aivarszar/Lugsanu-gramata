package net.convocatis.convocatis.ui.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

import net.convocatis.convocatis.R;
import net.convocatis.convocatis.database.model.GroupModel;
import net.convocatis.convocatis.database.model.LanguageModel;
import net.convocatis.convocatis.database.model.NotificationModel;
import net.convocatis.convocatis.diskmanager.DiskTask;
import net.convocatis.convocatis.networking.SynchronizationService;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by reactor on 1/25/16.
 */
public class NotificationNewFragment extends BaseFragment {
    public NotificationModel mNotificationModel;

    private EditText mTextEdit;
    private Spinner mGroupsSpinner;
    private Button mCreateButton;

    private List<GroupModel> mGroups;
    private ArrayList<String> mGroupNames;

    private LayoutInflater mLayoutInflater;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mNotificationModel = new NotificationModel();
        mNotificationModel.message = "";
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mLayoutInflater = inflater;

        View v = inflater.inflate(R.layout.notification_new_fragment, container, false);

        mTextEdit = (EditText) v.findViewById(R.id.text_edit);
        mGroupsSpinner = (Spinner) v.findViewById(R.id.groups_spinner);

        mCreateButton = (Button) v.findViewById(R.id.create_button);

        new DiskTask() {
            List<GroupModel> groups;

            @Override
            public void getData() {
                groups = GroupModel.getAllGroups();

                List<GroupModel> groups2 = new ArrayList<GroupModel>();

                for (GroupModel model : groups) {
                    if (!TextUtils.isEmpty(model.joined) || model.tryingToJoin) {
                        groups2.add(model);
                    }
                }

                groups = groups2;
            }

            @Override
            public void onDataReceived() {
                mGroups = groups;
                onDataLoaded();
            }
        }.execute(this);

        return v;
    }

    public void onDataLoaded() {

        mGroupNames = new ArrayList<String>();

        for (int i = 0; i < mGroups.size(); i++) {
            mGroupNames.add(mGroups.get(i).name);
        }

        final ArrayAdapter<String> languagesAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_list_item_1,
                mGroupNames);
        mGroupsSpinner.setAdapter(languagesAdapter);

        if (mNotificationModel.groupId == null) {
            mNotificationModel.groupId = mGroups.get(0).backendId;
        }

        int selectedLanguage = 0;

        for (int i = 0; i < mGroups.size(); i++) {
            if (mGroups.get(i).backendId == mNotificationModel.groupId) {
                selectedLanguage = i;
                break;
            }
        }

        mGroupsSpinner.setSelection(selectedLanguage);


        mTextEdit.setText(mNotificationModel.message);

        mCreateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mNotificationModel.backendId = (long) -1;
                mNotificationModel.message = mTextEdit.getText().toString();
                mNotificationModel.groupId = mGroups.get(mGroupsSpinner.getSelectedItemPosition()).backendId;


                new DiskTask() {
                    @Override
                    public void getData() {
                        mNotificationModel.persist();
                    }

                    @Override
                    public void onDataReceived() {
                        SynchronizationService.startSync(true);
                        mMainActivity.goBack();
                    }
                }.execute(NotificationNewFragment.this);

            }
        });
    }
}
