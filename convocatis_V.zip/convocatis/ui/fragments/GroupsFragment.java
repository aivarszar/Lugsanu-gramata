package net.convocatis.convocatis.ui.fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import net.convocatis.convocatis.R;
import net.convocatis.convocatis.database.model.GroupModel;
import net.convocatis.convocatis.database.model.TextModel;
import net.convocatis.convocatis.diskmanager.DiskTask;
import net.convocatis.convocatis.networking.API;
import net.convocatis.convocatis.networking.SynchronizationService;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by reactor on 1/25/16.
 */
public class GroupsFragment extends BaseFragment {

    public class MyAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return mGroups.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final GroupModel model = mGroups.get(position);

            View view = mLayoutInflater.inflate(R.layout.groups_item, parent, false);

            TextView titleText = (TextView) view.findViewById(R.id.title_text);
            View detailsLayout = view.findViewById(R.id.details_layout);
            TextView prevText = (TextView) view.findViewById(R.id.preview_text);
            TextView privateText = (TextView) view.findViewById(R.id.private_text);
            View membersButton = view.findViewById(R.id.members_button);
            View invitationText = view.findViewById(R.id.invitation_text);
            View joinedText = view.findViewById(R.id.joined_text);

            if (TextUtils.equals(model.invited, "true") && TextUtils.isEmpty(model.joined)) {
                invitationText.setVisibility(View.VISIBLE);
            } else {
                invitationText.setVisibility(View.GONE);
            }

            if (model.isPrivate != null && model.isPrivate) {
                privateText.setVisibility(View.VISIBLE);
            } else {
                privateText.setVisibility(View.GONE);
            }

            if (model.isPrivate != null && model.isPrivate && model.backendId != null) {
                membersButton.setVisibility(View.VISIBLE);

            } else {
                membersButton.setVisibility(View.GONE);
            }

            if (model.expanded) {
                detailsLayout.setVisibility(View.VISIBLE);
            } else {
                detailsLayout.setVisibility(View.GONE);
            }

            titleText.setText(model.name);
            prevText.setText(model.description);

            View joinButton = view.findViewById(R.id.join_button);
            View inviteButton = view.findViewById(R.id.invite_button);
            TextView joinText = (TextView) view.findViewById(R.id.join_text);

            if (TextUtils.isEmpty(model.joined)) {
                joinText.setText("Join");
                joinedText.setVisibility(View.GONE);
            } else {
                joinText.setText("Leave");
                joinedText.setVisibility(View.VISIBLE);
            }


            if (model.backendId != null && model.backendId != -1 && model.isPrivate != null && model.isPrivate) {

            } else {
                inviteButton.setVisibility(View.GONE);
            }

            joinButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    new DiskTask() {
                        @Override
                        public void getData() {

                            if (model.tryingToJoin || !TextUtils.isEmpty(model.joined)) {
                                model.tryingToJoin = false;
                                model.tryingToLeave = true;
                                model.joined = null;
                            } else {
                                model.tryingToJoin = true;
                                model.tryingToLeave = false;
                                model.joined = "1";
                            }

                            model.persist();
                        }

                        @Override
                        public void onDataReceived() {
                            notifyDataSetChanged();
                            SynchronizationService.startSync(true);
                        }
                    }.execute(GroupsFragment.this);

                }
            });

            inviteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    invite(model);
                }
            });

            membersButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    new DiskTask() {

                        ArrayList<String> members = new ArrayList<String>();
                        JSONArray arr;

                        @Override
                        public void getData() {
                            arr = API.listGroupMembers(model.backendId);

                            if (arr != null) {
                                try {
                                    for (int i = 0; i < arr.length(); i++) {

                                        JSONObject o = arr.getJSONObject(i);

                                        String email = null;

                                        email = o.getString("email");
                                        members.add(email);


                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }

                        @Override
                        public void onDataReceived() {

                            if (arr == null) {
                                Toast.makeText(mMainActivity, "Unable to get a list of members", Toast.LENGTH_SHORT).show();
                            } else if (members.size() == 0) {
                                Toast.makeText(mMainActivity, "This group doesn't have any members", Toast.LENGTH_SHORT).show();
                            } else {
                                AlertDialog.Builder builderSingle = new AlertDialog.Builder(mMainActivity);
                                builderSingle.setTitle("Members");

                                builderSingle.setItems(members.toArray(new CharSequence[0]), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                });

                                builderSingle.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                });

                                builderSingle.show();


                            }


                        }
                    }.execute(GroupsFragment.this);

                }
            });

            return view;
        }
    }

    private void invite(final GroupModel group) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mMainActivity);

        View v = mLayoutInflater.inflate(R.layout.invite_dialog, null, false);

        final EditText emailEdit = (EditText) v.findViewById(R.id.email_edit);
        final CheckBox adminCheckbox = (CheckBox) v.findViewById(R.id.admin_checkbox);

        builder.setView(v);

        builder.setPositiveButton("OK", null);

        builder.setTitle("Invite");

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        final AlertDialog dialog = builder.create();

        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface d) {

                Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                positive.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {

                        final String email = emailEdit.getText().toString();
                        final boolean admin = adminCheckbox.isChecked();

                        if (!TextUtils.isEmpty(email)) {


                            new DiskTask() {

                                @Override
                                public void getData() {
                                    JSONObject obj = API.inviteToGroup(group.backendId, email, admin);
                                }

                                @Override
                                public void onDataReceived() {

                                }
                            }.execute(GroupsFragment.this);

                            //Dismiss once everything is OK.
                            dialog.dismiss();

                        } else {
                            Toast.makeText(mMainActivity, "Email is empty", Toast.LENGTH_SHORT).show();
                        }


                    }
                });


            }
        });

        dialog.show();


    }

    private List<GroupModel> mGroups;
    private ListView mListView;
    private MyAdapter mAdapter;
    private LayoutInflater mLayoutInflater;
    private FloatingActionButton mActionButton;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mLayoutInflater = inflater;
        View v = inflater.inflate(R.layout.groups_fragment, container, false);

        mActionButton = (FloatingActionButton) v.findViewById(R.id.action_button);

        mActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMainActivity.switchToGroupNewFragment(false);
            }
        });

        mListView = (ListView) v.findViewById(R.id.list_view);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {

                if (mGroups.get(position).expanded) {
                    mGroups.get(position).expanded = false;
                } else {
                    for (GroupModel model : mGroups) {
                        model.expanded = false;
                    }
                    mGroups.get(position).expanded = true;
                }


                mAdapter.notifyDataSetChanged();
            }
        });

        mAdapter = new MyAdapter();

        new DiskTask() {

            @Override
            public void getData() {
                mGroups = GroupModel.getAllGroups();
            }

            @Override
            public void onDataReceived() {
                mListView.setAdapter(mAdapter);
            }

        }.execute(this);

        return v;
    }


}
