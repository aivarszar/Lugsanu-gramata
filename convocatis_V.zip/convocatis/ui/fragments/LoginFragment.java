package net.convocatis.convocatis.ui.fragments;

import android.app.Activity;
import android.app.Notification;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.plus.Plus;
import com.google.android.gms.plus.model.people.Person;
import com.google.gson.annotations.Expose;

import net.convocatis.convocatis.MyApplication;
import net.convocatis.convocatis.R;
import net.convocatis.convocatis.database.model.DenominationModel;
import net.convocatis.convocatis.database.model.GroupModel;
import net.convocatis.convocatis.database.model.LanguageModel;
import net.convocatis.convocatis.database.model.NotificationModel;
import net.convocatis.convocatis.database.model.ProfileModel;
import net.convocatis.convocatis.database.model.TextModel;
import net.convocatis.convocatis.database.model.TextUsageModel;
import net.convocatis.convocatis.diskmanager.DiskTask;
import net.convocatis.convocatis.networking.API;
import net.convocatis.convocatis.networking.SynchronizationService;
import net.convocatis.convocatis.receivers.AlarmReceiver;
import net.convocatis.convocatis.ui.MainActivity;
import net.convocatis.convocatis.utils.SimpleSHA1;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.Locale;
import java.util.List;
import java.util.ArrayList;


/**
 * Created by reactor on 1/25/16.
 */
public class LoginFragment extends BaseFragment implements GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener, MainActivity.OnActivityResultListener {

    private static final int RC_SIGN_IN = 123;
    public static final String DO_LOGOUT_PARAM = "DO_LOGOUT_PARAM";

    private LoginButton mFacebookLoginButton;
    private SignInButton mGoogleLoginButton;
    private CallbackManager callbackManager;
    private GoogleApiClient mGoogleApiClient;
    private boolean mShouldResolve = false;
    private boolean mIsResolving = false;
    private View mButtonsLayout;
    private EditText mEmailEdit, mPasswordEdit;
    private Button mLoginButton;
    private Button mForgotButton;

    private boolean mDoLogout = false;


    private LoginTask mLoginTask;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mDoLogout = getArguments().getBoolean(DO_LOGOUT_PARAM, false);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.login_fragment, container, false);

        mForgotButton = (Button) v.findViewById(R.id.forgot_button);

        mMainActivity.setOnActivityResultListener(this);

        mButtonsLayout = v.findViewById(R.id.buttons_layout);

        mEmailEdit = (EditText) v.findViewById(R.id.login_email_edit);
        mPasswordEdit = (EditText) v.findViewById(R.id.login_password_edit);
        mLoginButton = (Button) v.findViewById(R.id.login_button);

        mLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboard();
                onLoginWithEmail(mEmailEdit.getText().toString(), mPasswordEdit.getText().toString());
            }
        });

        mFacebookLoginButton = (LoginButton) v.findViewById(R.id.facebook_login_button);
        mFacebookLoginButton.setReadPermissions(Arrays.asList("email"));
        mFacebookLoginButton.setFragment(this);
        callbackManager = CallbackManager.Factory.create();

        // Callback registration
        mFacebookLoginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(final LoginResult loginResult) {

                Log.d("haha", "facebook onSuccess");
                showProgressDialog();
                mButtonsLayout.setVisibility(View.GONE);

                GraphRequest request = GraphRequest.newMeRequest(
                        loginResult.getAccessToken(),
                        new GraphRequest.GraphJSONObjectCallback() {
                            @Override
                            public void onCompleted(
                                    JSONObject object,
                                    GraphResponse response) {
                                // Application code

                                if (object == null) {
                                    facebookLogout();
                                    onFacebookLoginFailed();
                                    return;
                                }

                                Log.d("haha", "GraphJSONObjectCallback " + object.toString());

                                try {
                                    String email = response.getJSONObject().getString("email");
                                    onFacebookLoginSuccess(email);

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    facebookLogout();
                                    onFacebookLoginFailed();
                                    return;
                                }

                            }
                        });

                Bundle parameters = new Bundle();
                parameters.putString("fields", "email");
                request.setParameters(parameters);
                request.executeAsync();
            }

            @Override
            public void onCancel() {
                onFacebookLoginFailed();
            }

            @Override
            public void onError(FacebookException exception) {
                onFacebookLoginFailed();
            }
        });

        mGoogleLoginButton = (SignInButton) v.findViewById(R.id.sign_in_button);

        mGoogleLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mShouldResolve = true;
                mGoogleApiClient.connect();

                // Show a message to the user that we are signing in.
                // mStatusTextView.setText(R.string.signing_in);
            }
        });

        mGoogleApiClient = new GoogleApiClient.Builder(mMainActivity)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(Plus.API)
                .addScope(new Scope(Scopes.EMAIL))
                .build();

        if (mDoLogout) {
            logout();
        }

        mForgotButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mEmailEdit.getText().toString().length() == 0) {
                    Toast.makeText(mMainActivity, "Enter email to get a new password.", Toast.LENGTH_SHORT).show();
                } else {
                    new DiskTask() {

                        JSONObject o;

                        @Override
                        public void getData() {
                            o = API.forgotPassword(mEmailEdit.getText().toString());
                        }

                        @Override
                        public void onDataReceived() {

                            if (o == null) {
                                Toast.makeText(mMainActivity, "Network error.", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(mMainActivity, "Check your email for password change instructions.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }.execute(LoginFragment.this);
                }
            }
        });

        return v;
    }

    private void onFacebookLoginFailed() {
        Toast.makeText(mMainActivity, "Unable to log in with facebook account.", Toast.LENGTH_LONG).show();
        dismissProgressDialog();
        mButtonsLayout.setVisibility(View.VISIBLE);
    }

    private void onGoogleLoginFailed() {
        Toast.makeText(mMainActivity, "Unable to log in with google account.", Toast.LENGTH_LONG).show();
        dismissProgressDialog();
    }

    private void onFacebookLoginSuccess(String email) {
        if (mLoginTask != null) {
            return;
        }

        mLoginTask = new LoginTask(false, true, false, email, null);
        mLoginTask.execute(this);
        dismissProgressDialog();
    }

    private void onGoogleLoginSuccess(String email) {
        Log.d("haha", "google login: " + email);
        if (mLoginTask != null) {
            return;
        }
        mLoginTask = new LoginTask(false, false, true, email, null);
        mLoginTask.execute(this);
    }

    private void onLoginWithEmail(String email, String password) {
        if (mLoginTask != null) {
            return;
        }
        mLoginTask = new LoginTask(true, false, false, email, password);
        mLoginTask.execute(this);
    }

    public class LogoutTask extends DiskTask {
        @Override
        public void getData() {
            ProfileModel.clearWithSave();
        }

        @Override
        public void onDataReceived() {
            Log.d("haha", "logout complete");
        }
    }

    public class LoginTask extends DiskTask {
        private boolean mEmailLogin, mFacebookLogin, mGoogleLogin;
        private String mEmail, mPassword, mLanguage, mCountry;
        private JSONObject mResponse;
        private boolean loggedIn = false;
        private boolean verificationNeeded = false;
        private boolean blocked = false;

        public LoginTask(boolean emailLogin, boolean facebookLogin, boolean googleLogin, String email, String password) {
            mEmailLogin = emailLogin;
            mFacebookLogin = facebookLogin;
            mGoogleLogin = googleLogin;
            mEmail = email;
            if (password != null) {
                mPassword = SimpleSHA1.doubleSHA1(password);
            }

            mLanguage = Locale.getDefault().getLanguage();
            mCountry = Locale.getDefault().getCountry();
        }

        @Override
        public void getData() {

            try {
                if (mEmailLogin) {
                    mResponse = API.emailLogin(mEmail, mPassword, mLanguage, mCountry);
                } else if (mFacebookLogin) {
                    mResponse = API.facebookLogin(mEmail, mLanguage, mCountry);
                } else if (mGoogleLogin) {
                    mResponse = API.googleLogin(mEmail, mLanguage, mCountry);
                }

                JSONObject userData = null;

                if (mResponse != null && mResponse.has("User_data")) {
                    try {
                        userData = mResponse.getJSONObject("User_data");

                        if (userData.getInt("Verified") == 0) {
                            userData = null;
                            verificationNeeded = true;
                        }

                    } catch (JSONException e) {
                        userData = null;
                    }
                }

                try {
                    if (mResponse != null && !mResponse.has("User_data") && mResponse.has("Verified") && !mResponse.getBoolean("Verified")) {
                        verificationNeeded = true;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (userData != null) {
                    GroupModel.clearAll();
                    LanguageModel.clearAll();
                    TextModel.clearAll();
                    NotificationModel.clearAll();
                    TextUsageModel.clearAll();

                    try {

                        JSONObject jo = API.syncTime(0);

                        try {
                            if (jo == null || !jo.has("status") || jo.isNull("status") || !jo.getString("status").equals("true")) {
                                return;
                            }
                        } catch (JSONException e) {
                            return;
                        }

                        JSONObject syncResult = API.sync(null, null, null);

                        if (syncResult == null) {
                            return;
                        }

                        SynchronizationService.handleSyncResult(syncResult);

                        JSONArray denominations = API.listDenominations();

                        if (denominations == null) {
                            return;
                        }

                        List<DenominationModel> denominationsList = new ArrayList<DenominationModel>();
                        for (int i = 0; i < denominations.length(); i++) {
                            JSONObject d = denominations.getJSONObject(i);
                            DenominationModel dm = new DenominationModel();

                            dm.backendId = d.getLong("ID");
                            dm.name = d.getString("Denom_name");
                            dm.type = d.getString("Type");
                            dm.religion = d.getInt("Religion");
                            dm.description = d.getString("Description");

                            denominationsList.add(dm);
                        }
                        DenominationModel.replaceAll(denominationsList);

                        JSONObject result = API.syncTime(System.currentTimeMillis() / 1000);

                        if (result == null || !result.has("status") || result.isNull("status") || !result.getString("status").equals("true")) {
                            return;
                        }

                        ProfileModel m = ProfileModel.get();

                        m.email = userData.getString("Email");
                        m.id = userData.getLong("ID");
                        m.hasNews = userData.getInt("Has_news");
                        m.invString = userData.isNull("Inv_string") ? null : userData.getString("Inv_string");
                        m.syncTime = userData.isNull("Sync_time") ? null : userData.getLong("Sync_time");
                        m.notificationsEnabled = userData.isNull("Stop_notifications") ? true : (userData.getInt("Stop_notifications") == 1 ? false : true);
                        m.authService = userData.getInt("Auth_service");
                        m.otherDenominationsEnabled = userData.isNull("Others") ? false : (userData.getInt("Others") != 0);

                        m.uiLangId = userData.getLong("UI_Lang");
                        m.sponsor = userData.isNull("Sponsor") ? null : userData.getInt("Sponsor");
                        m.denominationId = userData.isNull("Denomination") ? null : userData.getLong("Denomination");
                        m.myLanguagesIds = mResponse.getString("My_languages");
                        m.myServerLanguagesIds = mResponse.getString("My_languages");
                        m.name = userData.isNull("First_name") ? "" : userData.getString("First_name");
                        m.surname = userData.isNull("Surname") ? "" : userData.getString("Surname");
                        m.nick = userData.isNull("Nick") ? "" : userData.getString("Nick");

                        m.emailDirty = false;
                        m.nameSurnameNickDirty = false;
                        m.syncTimeDirty = false;
                        m.notificationsEnabledDirty = false;
                        m.otherDenominationsEnabledDirty = false;
                        m.uiLangIdDirty = false;
                        m.denominationIdDirty = false;
                        m.themeIdDirty = false;
                        m.loggedIn = true;

                        m.save(false);

                        List<NotificationModel> notifications = NotificationModel.getAllNotifications();

                        if (notifications.size() > 0) {
                            AlarmReceiver.showNotification(MyApplication.get(), (int) (notifications.get(0).backendId + 0), null, "Convocatis notification", "You have new notifications", false);
                        }

                        loggedIn = true;

                    } catch (JSONException e) {
                        Log.d("haha", "exception: ", e);

                    }
                }

            } catch (Exception e) {
                Log.d("haha", "ex", e);
            }
        }

        @Override
        public void onDataReceived() {
            mLoginTask = null;

            boolean doLogout = false;

            if (mResponse == null) {
                doLogout = true;
                Toast.makeText(mMainActivity, "Network error.", Toast.LENGTH_SHORT).show();
            } else if (verificationNeeded) {
                doLogout = true;
                Toast.makeText(mMainActivity, "Check your email for activation link.", Toast.LENGTH_SHORT).show();
            } else if (loggedIn) {
                mMainActivity.switchToProfileFragment(false);
            } else {
                doLogout = true;
                Toast.makeText(mMainActivity, "Unable to log in.", Toast.LENGTH_SHORT).show();
            }

            if (doLogout) {
                mDoLogout = true;
                facebookLogout();
                mGoogleApiClient.connect();
            }
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        mMainActivity.setOnActivityResultListener(null);
    }

    private void logout() {
        facebookLogout();
        mGoogleApiClient.connect();

        LogoutTask logoutTask = new LogoutTask();
        logoutTask.execute(this);
    }

    private void facebookLogout() {
        LoginManager.getInstance().logOut();
        mButtonsLayout.setVisibility(View.VISIBLE);
    }

    private void googleLogout() {
        if (mGoogleApiClient.isConnected()) {
            Plus.AccountApi.clearDefaultAccount(mGoogleApiClient);
            mGoogleApiClient.disconnect();
        }
    }

    @Override
    public void onConnected(Bundle bundle) {
        mShouldResolve = false;
        Log.d("haha", "onConnected");

        if (mDoLogout) {
            googleLogout();
            mDoLogout = false;
        } else {
            String email = Plus.AccountApi.getAccountName(mGoogleApiClient);
            onGoogleLoginSuccess(email);
            mGoogleApiClient.disconnect();
        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    private void showErrorDialog(ConnectionResult connectionResult) {
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.d("haha", "google connection failed");

        // Could not connect to Google Play Services.  The user needs to select an account,
        // grant permissions or resolve an error in order to sign in. Refer to the javadoc for
        // ConnectionResult to see possible error codes.

        if (!mIsResolving && mShouldResolve) {
            if (connectionResult.hasResolution()) {
                try {
                    connectionResult.startResolutionForResult(mMainActivity, RC_SIGN_IN);
                    mIsResolving = true;
                } catch (IntentSender.SendIntentException e) {
                    mIsResolving = false;
                    mGoogleApiClient.connect();
                }
            } else {
                // Could not resolve the connection result, show the user an
                // error dialog.
                showErrorDialog(connectionResult);
            }
        } else {
            if (!mDoLogout) {
                onGoogleLoginFailed();
            }
        }

        mDoLogout = false;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        callbackManager.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onActivityResultCalled(int requestCode, int resultCode, Intent data) {

        if (requestCode == RC_SIGN_IN) {
            // If the error resolution was not successful we should not resolve further.
            if (resultCode != Activity.RESULT_OK) {
                mShouldResolve = false;
            }

            mIsResolving = false;
            mGoogleApiClient.connect();
        }

    }

    public void hideKeyboard() {
        // Check if no view has focus:
        View view = mMainActivity.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) mMainActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

}
