package net.convocatis.convocatis.ui.fragments;

import android.app.Activity;
import android.app.ProgressDialog;
import android.support.v4.app.Fragment;


import net.convocatis.convocatis.ui.MainActivity;

/**
 * Created by reactor on 1/25/16.
 */
public class BaseFragment extends Fragment {

    protected MainActivity mMainActivity;
    private ProgressDialog mProgressDialog;
    private int mProgressDialogCount;

    public void showProgressDialog() {

        mProgressDialogCount++;

        if (mProgressDialogCount > 1) {
            return;
        }

        mProgressDialog = new ProgressDialog(mMainActivity);
        mProgressDialog.setMessage("Loading please wait...");
        mProgressDialog.setCancelable(false);
        mProgressDialog.show();
    }

    public void dismissProgressDialog() {

        mProgressDialogCount--;

        if (mProgressDialogCount > 0) {
            return;
        }

        if (mProgressDialogCount < 0) {
            mProgressDialogCount = 0;
        }

        if (mProgressDialog != null) {
            try {
                mProgressDialog.dismiss();
            } catch (IllegalArgumentException e) {
            }
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        mMainActivity = (MainActivity) activity;
    }
}
