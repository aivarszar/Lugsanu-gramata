package net.convocatis.convocatis.ui.fragments;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.nononsenseapps.filepicker.FilePickerActivity;

import net.convocatis.convocatis.R;
import net.convocatis.convocatis.database.model.DenominationModel;
import net.convocatis.convocatis.database.model.LanguageModel;
import net.convocatis.convocatis.database.model.ProfileModel;
import net.convocatis.convocatis.database.model.TextModel;
import net.convocatis.convocatis.diskmanager.DiskTask;
import net.convocatis.convocatis.networking.SynchronizationService;
import net.convocatis.convocatis.receivers.AlarmReceiver;
import net.convocatis.convocatis.utils.Utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by reactor on 1/25/16.
 */
public class TextEditFragment extends BaseFragment {

    public static final String[] REPEATS_ARRAY = {"Daily", "Weekly", "Monthly", "Yearly"};

    public static final String TEXT_MODEL_PARAM = "TEXT_MODEL_PARAM";
    public static final String ORIGINAL_TEXT_MODEL_PARAM = "ORIGINAL_TEXT_MODEL_PARAM";

    public static final String TEXT_MODEL_SAVED = "TEXT_MODEL_SAVED";
    public static final String NEW_TEXT_SAVED = "NEW_TEXT_SAVED";
    public TextModel mTextModel, mOriginalTextModel;

    private EditText mTitleEdit, mTextEdit, mCodeEdit, mTypeEdit;
    private Spinner mLanguagesSpinner;
    private Button mScheduleButton, mFromFileButton, mCreateButton;
    private TextView mScheduleText, mNextPrayerText;

    private List<LanguageModel> mLanguages;
    private ArrayList<String> mLanguageNames;

    private boolean newText;

    private LayoutInflater mLayoutInflater;

    private int mDatePickerID, mTimePickerID;

    private void showDatePickerDialog(final EditText edit, final boolean withTime) {
        Calendar c = Calendar.getInstance();
        int startYear = c.get(Calendar.YEAR);
        int startMonth = c.get(Calendar.MONTH);
        int startDay = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(mMainActivity, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                if (mDatePickerID != 0) {
                    return;
                }

                mDatePickerID++;

                if (withTime) {
                    showTimePickerDialog(year, monthOfYear, dayOfMonth, edit);
                } else {
                    Calendar c = Calendar.getInstance();
                    c.set(Calendar.YEAR, year);
                    c.set(Calendar.MONTH, monthOfYear);
                    c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    c.set(Calendar.HOUR_OF_DAY, 0);
                    c.set(Calendar.MINUTE, 0);
                    c.set(Calendar.SECOND, 0);

                    Date date = c.getTime();
                    String dateString = Utils.dateToString(date);
                    edit.setText(dateString);
                }


            }
        }, startYear, startMonth, startDay);

        datePickerDialog.show();
        mDatePickerID = 0;
    }

    private void showTimePickerDialog(final int year, final int monthOfYear, final int dayOfMonth, final EditText edit) {
        Calendar c = Calendar.getInstance();
        int startHour = c.get(Calendar.HOUR_OF_DAY);
        int startMinute = c.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(mMainActivity, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                if (mTimePickerID != 0) {
                    return;
                }

                mTimePickerID++;

                Calendar c = Calendar.getInstance();
                c.set(Calendar.YEAR, year);
                c.set(Calendar.MONTH, monthOfYear);
                c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                c.set(Calendar.HOUR_OF_DAY, hourOfDay);
                c.set(Calendar.MINUTE, minute);
                c.set(Calendar.SECOND, 0);

                Date date = c.getTime();

                String dateString = Utils.dateTimeToString(date);

                edit.setText(dateString);

            }
        }, startHour, startMinute, true);

        timePickerDialog.show();
        mTimePickerID = 0;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (savedInstanceState == null) {

            mTextModel = (TextModel) getArguments().getSerializable(TEXT_MODEL_PARAM);

            if (mTextModel == null) {
                newText = true;
                mTextModel = new TextModel();
                mTextModel.type = 0;
                mTextModel.rating = 0;
                mTextModel.schedule = "";
                mTextModel.title = "";
                mTextModel.text = "";
                mTextModel.code = "";
            } else {
                newText = false;

                mOriginalTextModel = mTextModel;
                try {
                    mTextModel = (TextModel) mTextModel.clone();

                } catch (CloneNotSupportedException e) {
                }
            }
        } else {
            Log.d("haha", "onCreate restoring");

            mTextModel = (TextModel) savedInstanceState.getSerializable(TEXT_MODEL_SAVED);
            newText = savedInstanceState.getBoolean(NEW_TEXT_SAVED);
            mOriginalTextModel = (TextModel) savedInstanceState.getSerializable(ORIGINAL_TEXT_MODEL_PARAM);


            Log.d("haha", "onCreate restoring title = " + mTextModel.title);

        }
    }

    private void showScheduleDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mMainActivity);

        View v = mLayoutInflater.inflate(R.layout.schedule_dialog, null, false);

        final Spinner repeatsSpinner = (Spinner) v.findViewById(R.id.repeats_spinner);
        final Spinner repeatEverySpinner = (Spinner) v.findViewById(R.id.repeat_every_spinner);
        final View checkBoxesLayout = v.findViewById(R.id.checkboxes_layout);
        final EditText startsOnEdit = (EditText) v.findViewById(R.id.startson_edit);
        final EditText endsOnEdit = (EditText) v.findViewById(R.id.endson_edit);
        final EditText afterEdit = (EditText) v.findViewById(R.id.after_edit);
        final CheckBox checkBox0 = (CheckBox) v.findViewById(R.id.checkbox_0);
        final CheckBox checkBox1 = (CheckBox) v.findViewById(R.id.checkbox_1);
        final CheckBox checkBox2 = (CheckBox) v.findViewById(R.id.checkbox_2);
        final CheckBox checkBox3 = (CheckBox) v.findViewById(R.id.checkbox_3);
        final CheckBox checkBox4 = (CheckBox) v.findViewById(R.id.checkbox_4);
        final CheckBox checkBox5 = (CheckBox) v.findViewById(R.id.checkbox_5);
        final CheckBox checkBox6 = (CheckBox) v.findViewById(R.id.checkbox_6);

        final RadioButton mNeverRadio = (RadioButton) v.findViewById(R.id.radio_never);
        final RadioButton mAfterRadio = (RadioButton) v.findViewById(R.id.radio_after);
        final RadioButton mOnRadio = (RadioButton) v.findViewById(R.id.radio_on);

        final ArrayAdapter<String> repeatsAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_list_item_1,
                REPEATS_ARRAY);
        repeatsSpinner.setAdapter(repeatsAdapter);

        repeatsSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                                     @Override
                                                     public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                                         if (position == 1) {
                                                             checkBoxesLayout.setVisibility(View.VISIBLE);
                                                         } else {
                                                             checkBoxesLayout.setVisibility(View.GONE);
                                                         }
                                                     }

                                                     @Override
                                                     public void onNothingSelected(AdapterView<?> parent) {

                                                     }
                                                 }
        );


        String[] everyArray = new String[30];

        for (int i = 1; i <= 30; i++) {
            everyArray[i - 1] = "" + i;
        }

        final ArrayAdapter<String> everyAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_list_item_1,
                everyArray);
        repeatEverySpinner.setAdapter(everyAdapter);

        startsOnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(startsOnEdit, true);
            }
        });

        endsOnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(endsOnEdit, false);
                mOnRadio.setChecked(true);
            }
        });

        afterEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAfterRadio.setChecked(true);

            }
        });

        builder.setView(v);

        builder.setPositiveButton("OK", null);

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        final AlertDialog dialog = builder.create();

        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface d) {

                Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                positive.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {

                        if (startsOnEdit.getText().length() == 0) {
                            Toast.makeText(mMainActivity, "Select start date.", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        if (mAfterRadio.isChecked() && afterEdit.getText().length() == 0) {
                            Toast.makeText(mMainActivity, "Enter number of repetitions.", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        if (mOnRadio.isChecked() && endsOnEdit.getText().length() == 0) {
                            Toast.makeText(mMainActivity, "Enter end date.", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        String output = "";

                        output += startsOnEdit.getText().toString() + ";";
                        output += (repeatEverySpinner.getSelectedItemPosition() + 1) + ";";

                        switch (repeatsSpinner.getSelectedItemPosition()) {
                            case 0:
                                output += "d;;";
                                break;
                            case 1:

                                String days = "";

                                if (checkBox0.isChecked()) {
                                    days += "sun";
                                }

                                if (checkBox1.isChecked()) {
                                    if (days.length() > 0) days += ",";
                                    days += "mon";
                                }

                                if (checkBox2.isChecked()) {
                                    if (days.length() > 0) days += ",";
                                    days += "tue";
                                }

                                if (checkBox3.isChecked()) {
                                    if (days.length() > 0) days += ",";
                                    days += "wed";
                                }

                                if (checkBox4.isChecked()) {
                                    if (days.length() > 0) days += ",";
                                    days += "thu";
                                }

                                if (checkBox5.isChecked()) {
                                    if (days.length() > 0) days += ",";
                                    days += "fri";
                                }

                                if (checkBox6.isChecked()) {
                                    if (days.length() > 0) days += ",";
                                    days += "sat";
                                }

                                output += "w;" + days + ";";

                                break;
                            case 2:
                                output += "m;;";
                                break;
                            case 3:
                                output += "y;;";
                                break;
                        }

                        if (mNeverRadio.isChecked()) {
                            output += ";";
                        } else if (mAfterRadio.isChecked()) {
                            output += afterEdit.getText().toString() + ";";
                        } else if (mOnRadio.isChecked()) {
                            output += ";" + endsOnEdit.getText().toString();
                        }

                        mTextModel.schedule = output;
                        mScheduleText.setText(mTextModel.schedule);
                        mNextPrayerText.setText(mTextModel.getNextPrayerTimeString());

                        //Dismiss once everything is OK.
                        dialog.dismiss();
                    }
                });


            }
        });

        dialog.show();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

        mTextModel.title = mTitleEdit.getText().toString();
        mTextModel.text = mTextEdit.getText().toString();
        mTextModel.code = mCodeEdit.getText().toString();
        mTextModel.type = Integer.parseInt(mTypeEdit.getText().toString());

        outState.putSerializable(TEXT_MODEL_SAVED, mTextModel);
        outState.putBoolean(NEW_TEXT_SAVED, newText);
        outState.putSerializable(ORIGINAL_TEXT_MODEL_PARAM, mOriginalTextModel);

        Log.d("haha", "onSaveInstanceState");

        super.onSaveInstanceState(outState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mLayoutInflater = inflater;

        View v = inflater.inflate(R.layout.text_edit_fragment, container, false);

        mTitleEdit = (EditText) v.findViewById(R.id.title_edit);
        mTextEdit = (EditText) v.findViewById(R.id.text_edit);
        mLanguagesSpinner = (Spinner) v.findViewById(R.id.languages_spinner);
        mScheduleButton = (Button) v.findViewById(R.id.schedule_button);
        mFromFileButton = (Button) v.findViewById(R.id.from_file_button);
        mScheduleText = (TextView) v.findViewById(R.id.schedule_text);
        mCodeEdit = (EditText) v.findViewById(R.id.code_edit);
        mTypeEdit = (EditText) v.findViewById(R.id.type_edit);
        mNextPrayerText = (TextView) v.findViewById(R.id.next_prayer_text);
        mCreateButton = (Button) v.findViewById(R.id.create_button);

        if (newText) {
            mCreateButton.setText("Create");
        } else {
            mCreateButton.setText("Save");
        }

        mTextEdit.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (v.getId() == R.id.text_edit) {
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                    switch (event.getAction() & MotionEvent.ACTION_MASK) {
                        case MotionEvent.ACTION_UP:
                            v.getParent().requestDisallowInterceptTouchEvent(false);
                            break;
                    }
                }
                return false;
            }
        });

        new DiskTask() {
            List<LanguageModel> languages;

            @Override
            public void getData() {
                languages = LanguageModel.getAllLanguages();
            }

            @Override
            public void onDataReceived() {
                mLanguages = languages;
                onDataLoaded();
            }
        }.execute(this);

        return v;
    }

    public void onDataLoaded() {

        mLanguageNames = new ArrayList<String>();

        for (int i = 0; i < mLanguages.size(); i++) {
            mLanguageNames.add(mLanguages.get(i).name);
        }

        final ArrayAdapter<String> languagesAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_list_item_1,
                mLanguageNames);
        mLanguagesSpinner.setAdapter(languagesAdapter);

        if (mTextModel.langId == null) {
            mTextModel.langId = mLanguages.get(0).backendId;
        }

        int selectedLanguage = 0;

        for (int i = 0; i < mLanguages.size(); i++) {
            if (mLanguages.get(i).backendId == mTextModel.langId) {
                selectedLanguage = i;
                break;
            }
        }

        mLanguagesSpinner.setSelection(selectedLanguage);

        mTitleEdit.setText(mTextModel.title);
        mTextEdit.setText(mTextModel.text);

        mCodeEdit.setText(mTextModel.code);
        mTypeEdit.setText("" + mTextModel.type);

        if (TextUtils.isEmpty(mTextModel.schedule)) {
            mScheduleText.setText("---");
            mNextPrayerText.setText("---");
        } else {
            mScheduleText.setText(mTextModel.schedule);
            mNextPrayerText.setText(mTextModel.getNextPrayerTimeString());
        }

        mScheduleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showScheduleDialog();
            }
        });

        mFromFileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                // This always works
                Intent i = new Intent(mMainActivity, FilePickerActivity.class);
                // This works if you defined the intent filter
                // Intent i = new Intent(Intent.ACTION_GET_CONTENT);

                // Set these depending on your use case. These are the defaults.
                i.putExtra(FilePickerActivity.EXTRA_ALLOW_MULTIPLE, false);
                i.putExtra(FilePickerActivity.EXTRA_ALLOW_CREATE_DIR, false);
                i.putExtra(FilePickerActivity.EXTRA_MODE, FilePickerActivity.MODE_FILE);

                // Configure initial directory by specifying a String.
                // You could specify a String like "/storage/emulated/0/", but that can
                // dangerous. Always use Android's API calls to get paths to the SD-card or
                // internal memory.
                i.putExtra(FilePickerActivity.EXTRA_START_PATH, Environment.getExternalStorageDirectory().getPath());

                startActivityForResult(i, 100);
            }
        });

        mLanguagesSpinner.post(new Runnable() {
            @Override
            public void run() {

                mLanguagesSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        mTextModel.langId = mLanguages.get(position).backendId;
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
            }
        });

        mCreateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mTextModel.title = mTitleEdit.getText().toString();
                mTextModel.text = mTextEdit.getText().toString();
                mTextModel.code = mCodeEdit.getText().toString();
                mTextModel.type = Integer.parseInt(mTypeEdit.getText().toString());

                new DiskTask() {
                    @Override
                    public void getData() {

                        if (mOriginalTextModel != null) {

                            boolean makePrivate = false;

                            if (!TextUtils.equals(mOriginalTextModel.title, mTextModel.title)) {
                                makePrivate = true;
                            }

                            if (!TextUtils.equals(mOriginalTextModel.text, mTextModel.text)) {
                                makePrivate = true;
                            }

                            if (!TextUtils.equals(mOriginalTextModel.code, mTextModel.code)) {
                                makePrivate = true;
                            }

                            if (mOriginalTextModel.langId != mTextModel.langId) {
                                makePrivate = true;
                            }

                            if (mOriginalTextModel.type != mTextModel.type) {
                                makePrivate = true;
                            }

                            if (makePrivate) {
                                mTextModel.originalId = mTextModel.backendId;
                                mTextModel.backendId = null;
                            }
                        }

                        mTextModel.persist();

                        long time = mTextModel.getNextPrayerTime();

                        if (time != -1 && mTextModel.highlighted) {
                            AlarmReceiver.startAlarm(mMainActivity, time, (int) (mTextModel.id * 1), "Prayer", mTextModel.title);
                        } else {
                            AlarmReceiver.cancelAlarm(mMainActivity, (int) (mTextModel.id * 1));

                        }
                    }

                    @Override
                    public void onDataReceived() {
                        mMainActivity.goBack();
                    }
                }.execute(TextEditFragment.this);
            }
        });
    }

    public static String convertStreamToString(InputStream is) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line = null;
        while ((line = reader.readLine()) != null) {
            sb.append(line).append("\n");
        }
        reader.close();
        return sb.toString();
    }

    public static String getStringFromFile(Uri filePath) throws Exception {
        File fl = new File(filePath.getPath());
        FileInputStream fin = new FileInputStream(fl);
        String ret = convertStreamToString(fin);
        fin.close();
        return ret;
    }

    public void handleFileUri(Uri uri) {
        if (uri != null) {
            try {
                String fileString = getStringFromFile(uri);
                mTextModel.text = fileString;
                mTextEdit.setText(fileString);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        Log.d("haha", "onActivityResult " + requestCode + "" + resultCode);

        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            Uri uri = data.getData();
            handleFileUri(uri);
        }
    }

}
