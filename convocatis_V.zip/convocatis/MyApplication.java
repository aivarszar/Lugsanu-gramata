package net.convocatis.convocatis;

import android.app.Application;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import net.convocatis.convocatis.database.Database;
import net.convocatis.convocatis.database.model.ProfileModel;
import net.convocatis.convocatis.database.model.TextModel;
import net.convocatis.convocatis.diskmanager.DiskTask;
import net.convocatis.convocatis.receivers.AlarmReceiver;

import java.util.List;

/**
 * Created by reactor on 1/21/16.
 */
public class MyApplication extends Application {

    private static MyApplication sApplication;

    private static Gson sGson;
    private static Database mDatabase;
    private Handler mHandler;

    @Override
    public void onCreate() {
        super.onCreate();

        sApplication = this;

        sGson = new GsonBuilder().setPrettyPrinting()
                .serializeNulls().excludeFieldsWithoutExposeAnnotation().create();

        mDatabase = new Database(this);
        mHandler = new Handler(getMainLooper());

        new DiskTask() {
            @Override
            public void getData() {

                if (!TextUtils.isEmpty(ProfileModel.get().email)) {
                    List<TextModel> texts = TextModel.getHighlightedTexts();

                    for (TextModel t : texts) {
                        long time = t.getNextPrayerTime();

                        if (time != -1) {
                            AlarmReceiver.startAlarm(get(), time, (int) (t.id * 1), "Prayer", t.title);
                        }
                    }
                }
            }

            @Override
            public void onDataReceived() {

            }
        }.execute();

    }

    public Handler getHandler() {
        return mHandler;
    }

    public static MyApplication get() {
        return sApplication;
    }

    public static Gson getGson() {
        return sGson;
    }

    public static Database getDB() {
        return mDatabase;
    }

    public static void executeOnUIThread(Runnable runnable) {
        sApplication.getHandler().post(runnable);
    }

}
